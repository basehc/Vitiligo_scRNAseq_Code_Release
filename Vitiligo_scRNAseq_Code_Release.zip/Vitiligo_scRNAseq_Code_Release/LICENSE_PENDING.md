# License selection required

No software license is assigned by this preparation step. Before making the repository
public, the authors/copyright holders should select and add an appropriate license (for
example, MIT, BSD-3-Clause, or GPL-3.0) according to institutional policy.

