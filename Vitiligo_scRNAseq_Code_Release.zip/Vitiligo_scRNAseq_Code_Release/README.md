# Code for integrative single-cell analysis of vitiligo

This repository accompanies the manuscript **“Deep learning-based integrative
single-cell transcriptomic analysis of vitiligo”** (Frontiers in Immunology,
Manuscript ID 1962144).

It contains the donor-level multiple-instance learning (MIL) architecture, learnable
gene-gating module, pseudobulk and integrated-ranking workflow, baseline comparisons,
independent-cohort evaluation, and analyses added during peer review. Small tabular
outputs used to audit the reported results are included under `results/`. Raw public
single-cell matrices and multi-gigabyte AnnData files are not redistributed.

## Code map

| File | Purpose |
|---|---|
| `src/analysis.py` | Discovery-cohort loading, QC, Harmony integration, gated-attention MIL, gate back-projection, pseudobulk analysis, and integrated gene ranking |
| `src/analysis_celltype.py` | Leiden clustering, marker-score annotation, cell composition with BH correction, IFN/cytotoxic scoring, and CD8 T-cell analysis |
| `src/baseline_comparison.py` | Logistic regression, random forest, XGBoost, mean-pooling MIL, and gated-attention MIL under identical donor-level outer folds |
| `src/external_validation_gse298871.py` | Completely held-out evaluation using six healthy and six lesional-vitiligo donors, with paired non-lesional samples used only for sensitivity analysis |
| `src/external_validation_global_test.py` | Exhaustive 924-allocation permutation tests for the classifier AUC and ten-measure directional omnibus statistic |
| `src/reviewer_revision_analysis.py` | BH-corrected composition analysis, PRJCA006797-only MIL sensitivity analysis, error distribution by dataset, and T-cell annotation validation figure |

The reviewer’s request for the **MIL architecture, gene-gating module, and integrated
ranking pipeline** is addressed principally by `analysis.py` and
`baseline_comparison.py`; the remaining scripts reproduce supporting analyses.

## Environment

The recorded analysis environment used Python 3.10.20. Create a compatible environment
with either:

```bash
conda env create -f environment.yml
conda activate vitiligo-scrnaseq
```

or:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

## Public data and directory layout

Download the public datasets described in `docs/DATA_LAYOUT.md` and arrange them under
`data/`. By default, each script treats the repository directory as the project root.
To keep data and outputs elsewhere, set:

```bash
export VITILIGO_PROJECT_ROOT=/absolute/path/to/project
```

For external validation, the supplied manifest is read from
`config/sample_manifest_GSE298871.csv`. A different manifest can be selected with
`GSE298871_MANIFEST`.

## Execution order

From the repository root:

```bash
python src/analysis.py
python src/analysis_celltype.py
python src/baseline_comparison.py
python src/external_validation_gse298871.py
python src/external_validation_global_test.py
python src/reviewer_revision_analysis.py
```

The same order is encoded in `run_all.sh`. The full workflow is computationally
intensive: the discovery AnnData checkpoints are approximately 3.8 GB each, and the MIL
steps operate on donor bags containing thousands of cells.

## Included audit outputs

- `results/discovery/`: gate importance, pseudobulk differential expression, and
  integrated ranking.
- `results/baselines/`: out-of-fold predictions, fold metrics, selected hyperparameters,
  and Supplementary Table S12.
- `results/external_validation/`: donor features, endpoint tests, predictions, global
  tests, and validation summary.
- `results/reviewer_revision/`: BH-corrected composition results and Supplementary
  Table S13.

## Quick checks

The checks do not require the raw datasets:

```bash
python -m compileall -q src tests
python tests/test_code_smoke.py
```

## Reproducibility notes

- All train/test partitions are made at the biological-donor level.
- External-cohort labels are not used for discovery-model fitting, feature selection,
  endpoint selection, or threshold tuning.
- Random seeds, fold definitions, model dimensions, training epochs, and probability
  thresholds are specified in the scripts.
- The included result tables are audit artifacts. Re-running the full workflow requires
  downloading the public input matrices.



