# Public data layout

The analysis uses public single-cell RNA-sequencing matrices. Data files are intentionally
not duplicated in the code archive.

## Discovery cohorts

```text
data/
├── PRJCA006797/
│   ├── H01/outs/filtered_gene_bc_matrices/GRCh38/
│   │   ├── matrix.mtx
│   │   ├── barcodes.tsv
│   │   └── genes.tsv
│   ├── H02/ ... H05/
│   └── P01/ ... P10/
├── GSE203262/
│   ├── PtA_processed/
│   │   ├── matrix.mtx
│   │   ├── barcodes.tsv
│   │   └── genes.tsv
│   └── PtC_processed/ ... PtG_processed/
└── GSE186476/
    ├── Healthy_D01_counts/
    │   ├── matrix.mtx.gz
    │   ├── barcodes.tsv.gz
    │   └── features.tsv.gz
    └── Healthy_D02_counts/ ... Healthy_D14_counts/
```

Discovery accessions and group sizes:

- PRJCA006797: 5 healthy controls and 10 patients with vitiligo.
- GSE203262: 6 patients with vitiligo.
- GSE186476: 14 healthy control donors.

## Independent cohort

Place GSE298871 Cell Ranger-format files under `data/GSE298871/`. The supplied
`config/sample_manifest_GSE298871.csv` maps the 17 samples to donor, condition, tissue
status, and primary-validation membership. Primary evaluation uses one sample from each
of six healthy donors and six lesional-vitiligo donors. Five paired non-lesional samples
are retained only for within-patient sensitivity analyses.

Expected file suffixes for each GSE298871 sample are:

```text
*_matrix.mtx.gz
*_barcodes.tsv.gz
*_features.tsv.gz
```

## Generated checkpoints

The first two scripts generate:

```text
output/adata_harmony.h5ad
output/adata_annotated.h5ad
```

These files are intentionally excluded from the release archive because each is several
gigabytes and can be regenerated from the public matrices.

