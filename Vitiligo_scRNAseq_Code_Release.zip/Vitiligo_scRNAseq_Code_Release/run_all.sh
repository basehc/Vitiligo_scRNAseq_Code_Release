#!/usr/bin/env bash
set -euo pipefail

repo_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
export VITILIGO_PROJECT_ROOT=${VITILIGO_PROJECT_ROOT:-$repo_dir}

python "$repo_dir/src/analysis.py"
python "$repo_dir/src/analysis_celltype.py"
python "$repo_dir/src/baseline_comparison.py"
python "$repo_dir/src/external_validation_gse298871.py"
python "$repo_dir/src/external_validation_global_test.py"
python "$repo_dir/src/reviewer_revision_analysis.py"

