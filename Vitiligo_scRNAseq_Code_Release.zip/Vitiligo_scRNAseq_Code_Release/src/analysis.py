"""
Vitiligo vs Healthy Skin - Multi-dataset Single-cell RNA-seq Analysis
Datasets: PRJCA006797 (5H+10P) + GSE203262 (6P) + GSE186476 (14H)
Total: 35 donors (19 healthy + 16 patient)
Method: Harmony integration + Donor-level Attention MIL + Pseudobulk DEG
"""

import os
import numpy as np
import pandas as pd
import scipy.io
import scipy.sparse
import scanpy as sc
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import warnings
warnings.filterwarnings("ignore")

import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import accuracy_score, roc_auc_score, confusion_matrix
import statsmodels.formula.api as smf
from statsmodels.stats.multitest import multipletests

GLOBAL_SEED = 42
MODEL_SEED_BASE = 2026
np.random.seed(GLOBAL_SEED)
torch.manual_seed(GLOBAL_SEED)

sc.settings.verbosity = 1
PROJECT_ROOT = Path(
    os.environ.get("VITILIGO_PROJECT_ROOT", Path(__file__).resolve().parents[1])
).resolve()
DATA_DIR = PROJECT_ROOT / "data"
OUT_DIR = PROJECT_ROOT / "output"
OUT_DIR.mkdir(parents=True, exist_ok=True)

# ─── 1. LOAD DATA ────────────────────────────────────────────────────────────
print("=== 1. Loading data ===")

def load_cellranger_v2(base_dir, donor_id, label, dataset):
    """Cell Ranger v2: genes.tsv (uncompressed). Auto-detects filename prefix."""
    base_dir = Path(base_dir)
    # Auto-detect file prefix (some samples use 'PtX_matrix.mtx' style)
    def find_file(stem):
        for f in base_dir.iterdir():
            if f.name == stem or f.name.endswith("_" + stem):
                return f
        raise FileNotFoundError(f"{stem} not found in {base_dir}")
    mat      = scipy.io.mmread(find_file("matrix.mtx")).T.tocsr()
    barcodes = pd.read_csv(find_file("barcodes.tsv"), header=None)[0].tolist()
    genes    = pd.read_csv(find_file("genes.tsv"), header=None, sep="\t")[1].tolist()
    adata = sc.AnnData(X=scipy.sparse.csr_matrix(mat))
    adata.obs_names = [f"{donor_id}_{b}" for b in barcodes]
    adata.var_names = genes
    adata.obs["donor"]   = donor_id
    adata.obs["label"]   = label
    adata.obs["dataset"] = dataset
    adata.var_names_make_unique()
    return adata

def load_cellranger_v3(base_dir, donor_id, label, dataset):
    """Cell Ranger v3: features.tsv.gz (compressed)."""
    import gzip
    def read_gz(path):
        with gzip.open(path, "rt") as f:
            return [l.strip() for l in f]
    # matrix.mtx.gz
    with gzip.open(base_dir / "matrix.mtx.gz", "rb") as f:
        mat = scipy.io.mmread(f).T.tocsr()
    barcodes = read_gz(base_dir / "barcodes.tsv.gz")
    features = read_gz(base_dir / "features.tsv.gz")
    genes = [line.split("\t")[1] if "\t" in line else line for line in features]
    adata = sc.AnnData(X=scipy.sparse.csr_matrix(mat))
    adata.obs_names = [f"{donor_id}_{b}" for b in barcodes]
    adata.var_names = genes
    adata.obs["donor"]   = donor_id
    adata.obs["label"]   = label
    adata.obs["dataset"] = dataset
    adata.var_names_make_unique()
    return adata

adatas = []

# --- Dataset 1: PRJCA006797 (5 healthy + 10 patient) ---
print("  [PRJCA006797]")
prjca_dir = DATA_DIR / "PRJCA006797"
for i in range(1, 6):
    sid = f"H{i:02d}"
    base = prjca_dir / sid / "outs" / "filtered_gene_bc_matrices" / "GRCh38"
    ad = load_cellranger_v2(base, f"PRJCA_{sid}", "healthy", "PRJCA006797")
    print(f"    {sid}: {ad.n_obs} cells")
    adatas.append(ad)
for i in range(1, 11):
    sid = f"P{i:02d}"
    base = prjca_dir / sid / "outs" / "filtered_gene_bc_matrices" / "GRCh38"
    ad = load_cellranger_v2(base, f"PRJCA_{sid}", "patient", "PRJCA006797")
    print(f"    {sid}: {ad.n_obs} cells")
    adatas.append(ad)

# --- Dataset 2: GSE203262 (6 patient donors) ---
print("  [GSE203262]")
gse203_dir = DATA_DIR / "GSE203262"
for pt in ["PtA", "PtC", "PtD", "PtE", "PtF", "PtG"]:
    base = gse203_dir / f"{pt}_processed"
    ad = load_cellranger_v2(base, f"GSE203_{pt}", "patient", "GSE203262")
    print(f"    {pt}: {ad.n_obs} cells")
    adatas.append(ad)

# --- Dataset 3: GSE186476 (14 healthy donors) ---
print("  [GSE186476]")
gse186_dir = DATA_DIR / "GSE186476"
for i in range(1, 15):
    dname = f"Healthy_D{i:02d}_counts"
    base  = gse186_dir / dname
    ad = load_cellranger_v3(base, f"GSE186_D{i:02d}", "healthy", "GSE186476")
    print(f"    D{i:02d}: {ad.n_obs} cells")
    adatas.append(ad)

# Concatenate on common genes
adata = sc.concat(adatas, join="inner")
print(f"\n  Total: {adata.n_obs} cells x {adata.n_vars} genes | "
      f"{adata.obs['donor'].nunique()} donors")
print(f"  Healthy: {(adata.obs['label']=='healthy').sum()} cells | "
      f"Patient: {(adata.obs['label']=='patient').sum()} cells")

# ─── 2. QUALITY CONTROL ──────────────────────────────────────────────────────
print("\n=== 2. Quality control ===")

adata.var["mt"] = adata.var_names.str.startswith("MT-")
sc.pp.calculate_qc_metrics(adata, qc_vars=["mt"], inplace=True)

before = adata.n_obs
adata = adata[
    (adata.obs["n_genes_by_counts"] >= 200) &
    (adata.obs["n_genes_by_counts"] <= 6000) &
    (adata.obs["total_counts"] >= 500) &
    (adata.obs["total_counts"] <= 50000) &
    (adata.obs["pct_counts_mt"] < 20)
].copy()
print(f"  Cells after QC: {adata.n_obs} (removed {before - adata.n_obs})")

# Per-dataset donor counts after QC
for ds in ["PRJCA006797", "GSE203262", "GSE186476"]:
    mask = adata.obs["dataset"] == ds
    n_d  = adata.obs.loc[mask, "donor"].nunique()
    print(f"    {ds}: {mask.sum()} cells, {n_d} donors")

# QC violin
fig, axes = plt.subplots(1, 3, figsize=(13, 4))
for ax, key, lab in zip(axes,
    ["n_genes_by_counts", "total_counts", "pct_counts_mt"],
    ["Genes/cell", "Total UMI", "MT%"]):
    for ds, color in [("PRJCA006797","#4C72B0"), ("GSE203262","#DD8452"), ("GSE186476","#55A868")]:
        vals = adata.obs.loc[adata.obs["dataset"]==ds, key]
        ax.hist(vals, bins=50, alpha=0.55, color=color, label=ds, density=True)
    ax.set_title(lab); ax.legend(fontsize=7)
plt.tight_layout()
plt.savefig(OUT_DIR / "qc_distributions.png", dpi=150)
plt.close()

# ─── 3. NORMALIZATION & HVG ──────────────────────────────────────────────────
print("\n=== 3. Normalization + HVG ===")

sc.pp.normalize_total(adata, target_sum=1e4)
sc.pp.log1p(adata)
adata.raw = adata.copy()

sc.pp.highly_variable_genes(adata, n_top_genes=3000, batch_key="dataset")
adata = adata[:, adata.var["highly_variable"]].copy()
print(f"  HVG selected: {adata.n_vars}")

# ─── 4. PCA + HARMONY (by dataset) ───────────────────────────────────────────
print("\n=== 4. PCA + Harmony (batch=dataset) ===")

sc.pp.scale(adata, max_value=10)
sc.tl.pca(adata, n_comps=50)

import harmonypy
ho = harmonypy.run_harmony(adata.obsm["X_pca"], adata.obs, "dataset",
                           max_iter_harmony=20)
adata.obsm["X_pca_harmony"] = ho.Z_corr
print("  Harmony done")

sc.pp.neighbors(adata, use_rep="X_pca_harmony", n_neighbors=15)
sc.tl.umap(adata)
print("  UMAP done")

# Save checkpoint for cell-type annotation step
adata.write_h5ad(OUT_DIR / "adata_harmony.h5ad")
print("  Checkpoint saved: adata_harmony.h5ad")

# UMAP plots
fig, axes = plt.subplots(1, 3, figsize=(18, 5))
sc.pl.umap(adata, color="label",   ax=axes[0], show=False, title="Label")
sc.pl.umap(adata, color="dataset", ax=axes[1], show=False, title="Dataset")
sc.pl.umap(adata, color="donor",   ax=axes[2], show=False, title="Donor",
           legend_loc="none")
plt.tight_layout()
plt.savefig(OUT_DIR / "umap_overview.png", dpi=150)
plt.close()

# ─── 5. DONOR-LEVEL ATTENTION MIL ────────────────────────────────────────────
print("\n=== 5. Donor-level Attention MIL ===")

donors  = adata.obs["donor"].unique().tolist()
labels  = {d: 0 if adata.obs.loc[adata.obs["donor"]==d, "label"].iloc[0]=="healthy" else 1
           for d in donors}
donor_X = {d: adata.obsm["X_pca_harmony"][adata.obs["donor"].values == d]
           for d in donors}

n_healthy = sum(v==0 for v in labels.values())
n_patient = sum(v==1 for v in labels.values())
print(f"  Donors: {len(donors)} total ({n_healthy} healthy, {n_patient} patient)")

INPUT_DIM = adata.obsm["X_pca_harmony"].shape[1]  # 50
HIDDEN, ATTN_DIM = 128, 64

class GeneGating(nn.Module):
    def __init__(self, in_dim):
        super().__init__()
        self.w = nn.Parameter(torch.ones(in_dim))
    def forward(self, x):
        gate = torch.sigmoid(self.w)
        return x * gate, gate

class AttentionMIL(nn.Module):
    def __init__(self, in_dim, hidden, attn_dim):
        super().__init__()
        self.gating  = GeneGating(in_dim)
        self.encoder = nn.Sequential(
            nn.Linear(in_dim, hidden), nn.LayerNorm(hidden), nn.GELU(),
            nn.Linear(hidden, hidden), nn.GELU()
        )
        self.attn_V = nn.Linear(hidden, attn_dim)
        self.attn_U = nn.Linear(hidden, attn_dim)
        self.attn_w = nn.Linear(attn_dim, 1)
        self.head   = nn.Linear(hidden, 1)

    def forward(self, x):
        x_g, gate = self.gating(x)
        h = self.encoder(x_g)
        a = self.attn_w(torch.tanh(self.attn_V(h)) * torch.sigmoid(self.attn_U(h)))
        a = torch.softmax(a, dim=0)
        z = (a * h).sum(dim=0, keepdim=True)
        return self.head(z).squeeze(), gate, a.squeeze()

def train_epoch(model, opt, donor_list, l1_lambda=1e-3):
    model.train()
    total = 0.0
    for d in donor_list:
        x = torch.tensor(donor_X[d], dtype=torch.float32)
        y = torch.tensor(float(labels[d]))
        opt.zero_grad()
        logit, gate, _ = model(x)
        loss = F.binary_cross_entropy_with_logits(logit, y) + l1_lambda * gate.abs().sum()
        loss.backward(); opt.step()
        total += loss.item()
    return total / len(donor_list)

def evaluate(model, donor_list):
    model.eval()
    trues, preds, probs, gates = [], [], [], []
    with torch.no_grad():
        for d in donor_list:
            x = torch.tensor(donor_X[d], dtype=torch.float32)
            logit, gate, _ = model(x)
            prob = torch.sigmoid(logit).item()
            probs.append(prob); preds.append(int(prob >= 0.5))
            trues.append(labels[d]); gates.append(gate.numpy())
    return trues, preds, probs, np.mean(gates, axis=0)

donor_arr = np.array(donors)
label_arr  = np.array([labels[d] for d in donors])
kf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

all_true, all_pred, all_prob, all_gates = [], [], [], []

for fold, (tr_idx, te_idx) in enumerate(kf.split(donor_arr, label_arr)):
    train_d = donor_arr[tr_idx].tolist()
    test_d  = donor_arr[te_idx].tolist()

    model_seed = MODEL_SEED_BASE + fold + 1
    np.random.seed(model_seed)
    torch.manual_seed(model_seed)
    model = AttentionMIL(INPUT_DIM, HIDDEN, ATTN_DIM)
    opt   = torch.optim.Adam(model.parameters(), lr=1e-3, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=100)

    for ep in range(100):
        train_epoch(model, opt, train_d); sched.step()

    trues, preds, probs, gates = evaluate(model, test_d)
    all_true.extend(trues); all_pred.extend(preds)
    all_prob.extend(probs); all_gates.append(gates)

    acc = accuracy_score(trues, preds)
    print(f"  Fold {fold+1}: acc={acc:.3f}  n_test={len(trues)}")

acc_final = accuracy_score(all_true, all_pred)
auc_final = roc_auc_score(all_true, all_prob)
cm        = confusion_matrix(all_true, all_pred)
mean_gate = np.mean(all_gates, axis=0)

print(f"\n  Accuracy : {acc_final:.3f}")
print(f"  AUC      : {auc_final:.3f}")
print(f"  Confusion matrix:\n{cm}")

# Confusion matrix plot
fig, ax = plt.subplots(figsize=(5, 4))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
            xticklabels=["Pred Healthy","Pred Patient"],
            yticklabels=["True Healthy","True Patient"], ax=ax)
ax.set_title(f"Donor-level MIL  Acc={acc_final:.3f}  AUC={auc_final:.3f}")
plt.tight_layout()
plt.savefig(OUT_DIR / "confusion_matrix.png", dpi=150)
plt.close()

# ─── 6. GENE IMPORTANCE FROM GATE WEIGHTS ────────────────────────────────────
print("\n=== 6. Gene importance (gate → PCA → genes) ===")

pca_components = adata.varm["PCs"]                          # (n_hvg, 50)
gene_importance = np.abs(pca_components @ mean_gate)        # (n_hvg,)
hvg_names = adata.var_names.tolist()

gene_imp_df = pd.DataFrame({"gene": hvg_names, "gate_score": gene_importance})\
    .sort_values("gate_score", ascending=False)
gene_imp_df.to_csv(OUT_DIR / "gene_importance_gate.csv", index=False)
print("  Top 20 by gate score:")
print(gene_imp_df.head(20).to_string(index=False))

# ─── 7. PSEUDOBULK DEG (dataset as covariate) ────────────────────────────────
print("\n=== 7. Pseudobulk DEG with dataset covariate ===")

raw_adata = adata.raw.to_adata()
raw_adata.obs["donor"]   = adata.obs["donor"].values
raw_adata.obs["label"]   = adata.obs["label"].values
raw_adata.obs["dataset"] = adata.obs["dataset"].values

# Build pseudobulk (sum counts per donor)
pb_list, pb_meta = [], []
for d in donors:
    mask = raw_adata.obs["donor"] == d
    pb   = np.asarray(raw_adata[mask].X.sum(axis=0)).flatten()
    pb_list.append(pb)
    pb_meta.append({
        "donor":   d,
        "label":   labels[d],
        "dataset": raw_adata.obs.loc[mask, "dataset"].iloc[0]
    })

pb_matrix = np.vstack(pb_list)
pb_df     = pd.DataFrame(pb_matrix, index=donors, columns=raw_adata.var_names)
pb_df     = pb_df[hvg_names]  # keep HVG only

pb_cpm = pb_df.div(pb_df.sum(axis=1), axis=0) * 1e6
pb_log = np.log1p(pb_cpm)
meta_df = pd.DataFrame(pb_meta, index=donors)

# Dataset one-hot for covariate
meta_df["ds_GSE203262"] = (meta_df["dataset"] == "GSE203262").astype(float)
meta_df["ds_GSE186476"] = (meta_df["dataset"] == "GSE186476").astype(float)

pvals, logfcs = [], []
for g in hvg_names:
    df_g = meta_df.copy()
    df_g["y"] = pb_log[g].values
    try:
        res = smf.ols("y ~ label + ds_GSE203262 + ds_GSE186476", data=df_g).fit()
        pvals.append(res.pvalues.get("label", 1.0))
        logfcs.append(res.params.get("label", 0.0))
    except Exception:
        pvals.append(1.0); logfcs.append(0.0)

_, padj, _, _ = multipletests(pvals, method="fdr_bh")
deg_df = pd.DataFrame({"gene": hvg_names, "logFC": logfcs,
                        "pval": pvals, "padj": padj})\
    .sort_values("padj")
deg_df.to_csv(OUT_DIR / "pseudobulk_DEG.csv", index=False)
print("  Top 20 DEGs:")
print(deg_df.head(20)[["gene","logFC","padj"]].to_string(index=False))

# Volcano plot
fig, ax = plt.subplots(figsize=(8, 6))
neg_log_p = -np.log10(deg_df["padj"].clip(lower=1e-30))
colors_v = ["red" if (p<0.05 and abs(fc)>0.5) else "lightgrey"
            for p, fc in zip(deg_df["padj"], deg_df["logFC"])]
ax.scatter(deg_df["logFC"], neg_log_p, c=colors_v, s=8, alpha=0.7)
ax.axhline(-np.log10(0.05), ls="--", color="black", lw=0.8)
ax.axvline(0.5,  ls="--", color="grey", lw=0.8)
ax.axvline(-0.5, ls="--", color="grey", lw=0.8)
ax.set_xlabel("logFC (patient vs healthy, dataset-adjusted)")
ax.set_ylabel("-log10 adj.p")
ax.set_title("Pseudobulk Volcano (35 donors, 3 datasets)")
for _, row in deg_df.head(20).iterrows():
    ax.text(row["logFC"], -np.log10(max(row["padj"],1e-30)), row["gene"], fontsize=6)
plt.tight_layout()
plt.savefig(OUT_DIR / "volcano.png", dpi=150)
plt.close()

# ─── 8. INTEGRATED RANKING ────────────────────────────────────────────────────
print("\n=== 8. Integrated gene ranking ===")

gate_norm = gene_imp_df.set_index("gene")["gate_score"]
gate_norm = gate_norm / gate_norm.max()

deg_score = (1 - deg_df.set_index("gene")["padj"]).clip(lower=0)
deg_score = deg_score / deg_score.max()

combined = pd.DataFrame({"gate_norm": gate_norm, "deg_score": deg_score}).dropna()
combined["combined_score"] = 0.5 * combined["gate_norm"] + 0.5 * combined["deg_score"]
combined["logFC"] = deg_df.set_index("gene")["logFC"]
combined = combined.sort_values("combined_score", ascending=False)
combined.reset_index().rename(columns={"index":"gene"})\
    .to_csv(OUT_DIR / "integrated_gene_ranking.csv", index=False)

print("\n  Top 20 integrated ranking:")
print(combined.head(20)[["gate_norm","deg_score","combined_score","logFC"]].to_string())

# Top-gene bar plot
fig, ax = plt.subplots(figsize=(10, 6))
top20 = combined.head(20).reset_index()
bar_colors = ["salmon" if fc > 0 else "steelblue" for fc in top20["logFC"]]
ax.barh(top20["gene"][::-1], top20["combined_score"][::-1], color=bar_colors[::-1])
ax.set_xlabel("Combined Score")
ax.set_title("Top 20 Candidate Genes — MIL gate + Pseudobulk DEG\n(red=up in patient, blue=down)")
plt.tight_layout()
plt.savefig(OUT_DIR / "top_genes_bar.png", dpi=150)
plt.close()

# ─── 9. SUMMARY ───────────────────────────────────────────────────────────────
print("\n" + "="*60)
print("ANALYSIS COMPLETE")
print(f"Total cells   : {adata.n_obs}")
print(f"Total donors  : {len(donors)} ({n_healthy} healthy, {n_patient} patient)")
print(f"Datasets      : PRJCA006797 + GSE203262 + GSE186476")
print(f"Accuracy      : {acc_final:.3f}")
print(f"AUC           : {auc_final:.3f}")
print(f"Outputs saved : {OUT_DIR}")
print("="*60)
