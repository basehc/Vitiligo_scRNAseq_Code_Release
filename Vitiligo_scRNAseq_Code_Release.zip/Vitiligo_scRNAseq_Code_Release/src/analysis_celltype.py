"""
Cell Type Annotation + Frontiers in Immunology Downstream Analysis
Loads harmony-corrected adata checkpoint, annotates cell types,
computes composition, IFN scores, and generates publication figures.
"""

import os
import numpy as np
import pandas as pd
import scanpy as sc
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns
from pathlib import Path
import warnings
warnings.filterwarnings("ignore")
from statsmodels.stats.multitest import multipletests

sc.settings.verbosity = 1
PROJECT_ROOT = Path(
    os.environ.get("VITILIGO_PROJECT_ROOT", Path(__file__).resolve().parents[1])
).resolve()
OUT_DIR = PROJECT_ROOT / "output"
OUT_DIR.mkdir(parents=True, exist_ok=True)

matplotlib.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
    "font.size": 9.5,
    "font.weight": "bold",
    "axes.titlesize": 12,
    "axes.titleweight": "bold",
    "axes.labelsize": 10.5,
    "axes.labelweight": "bold",
    "xtick.labelsize": 8.5,
    "ytick.labelsize": 8.5,
    "legend.fontsize": 8,
    "pdf.fonttype": 42,
    "svg.fonttype": "none",
})


def strengthen_figure_text(fig, minimum=7.5):
    """Increase and bold existing labels without changing data or plot geometry."""
    from matplotlib.text import Text

    for item in fig.findobj(match=Text):
        if not item.get_text().strip():
            continue
        item.set_fontsize(max(minimum, item.get_fontsize()))
        item.set_fontweight("bold")

# ─── LOAD CHECKPOINT ─────────────────────────────────────────────────────────
print("=== Loading checkpoint ===")
adata = sc.read_h5ad(OUT_DIR / "adata_harmony.h5ad")
print(f"  Loaded: {adata.n_obs} cells x {adata.n_vars} genes, {adata.obs['donor'].nunique()} donors")

# ─── 1. LEIDEN CLUSTERING ────────────────────────────────────────────────────
print("\n=== 1. Leiden clustering ===")
sc.tl.leiden(adata, resolution=0.6, random_state=42)
print(f"  Clusters: {adata.obs['leiden'].nunique()}")

# ─── 2. CELL TYPE MARKER DEFINITION ─────────────────────────────────────────
print("\n=== 2. Cell type annotation ===")

# Skin cell type markers (from published skin atlases)
MARKERS = {
    "Keratinocyte_basal":  ["KRT14", "KRT5", "TP63", "COL17A1", "ITGA6"],
    "Keratinocyte_supra":  ["KRT1", "KRT10", "KRTDAP", "FLG", "LORICRIN"],
    "Melanocyte":          ["PMEL", "MLANA", "DCT", "TYRP1", "MITF"],
    "Fibroblast":          ["COL1A1", "COL1A2", "DCN", "LUM", "PDGFRA"],
    "CD8_T":               ["CD3D", "CD8A", "GZMK", "GZMA", "PRF1", "NKG7"],
    "CD4_T":               ["CD3D", "CD4", "IL7R", "MAL"],
    "Treg":                ["FOXP3", "IL2RA", "CTLA4", "IKZF2"],
    "NK":                  ["GNLY", "NKG7", "KLRD1", "KIR2DL4", "KLRC2"],
    "Macrophage":          ["CD68", "CD14", "LYZ", "MRC1", "CSF1R"],
    "Dendritic":           ["CLEC9A", "CD1C", "LAMP3", "CCR7", "ITGAX"],
    "Endothelial":         ["PECAM1", "VWF", "CDH5", "CLDN5"],
    "Mast":                ["TPSAB1", "CPA3", "KIT"],
    "Plasma_B":            ["MZB1", "IGHG1", "IGHG4", "IGKC", "MS4A1"],
}

# Score each cluster against each cell type using sc.tl.score_genes
for ct, genes in MARKERS.items():
    present = [g for g in genes if g in adata.var_names]
    if present:
        sc.tl.score_genes(adata, present, score_name=f"score_{ct}", use_raw=False)

# Assign cell type to each cluster: pick highest mean score
score_cols = [f"score_{ct}" for ct in MARKERS]
cluster_scores = adata.obs.groupby("leiden")[score_cols].mean()
cluster_scores.columns = list(MARKERS.keys())
cluster_to_ct = cluster_scores.idxmax(axis=1).to_dict()
adata.obs["cell_type"] = adata.obs["leiden"].map(cluster_to_ct)

# Print cluster assignments
print("  Cluster → Cell type:")
for cl, ct in sorted(cluster_to_ct.items(), key=lambda x: int(x[0])):
    n = (adata.obs["leiden"] == cl).sum()
    print(f"    Cluster {cl:>2}: {ct:<25} ({n} cells)")

n_per_ct = adata.obs["cell_type"].value_counts()
print(f"\n  Cell types found: {len(n_per_ct)}")
print(n_per_ct.to_string())

# ─── 3. PUBLICATION FIGURE 1: UMAP OVERVIEW ──────────────────────────────────
print("\n=== 3. Figure 1 — UMAP overview ===")

# Color palette for cell types
CT_PALETTE = {
    "Keratinocyte_basal":  "#E64B35",
    "Keratinocyte_supra":  "#F39B7F",
    "Melanocyte":          "#7E6148",
    "Fibroblast":          "#00A087",
    "CD8_T":               "#3C5488",
    "CD4_T":               "#4DBBD5",
    "Treg":                "#8491B4",
    "NK":                  "#91D1C2",
    "Macrophage":          "#B09C85",
    "Dendritic":           "#DC0000",
    "Endothelial":         "#F0A500",
    "Mast":                "#7CAE00",
    "Plasma_B":            "#C77CFF",
}
adata.obs["cell_type"] = pd.Categorical(adata.obs["cell_type"])
adata.uns["cell_type_colors"] = [
    CT_PALETTE.get(ct, "#AAAAAA")
    for ct in adata.obs["cell_type"].cat.categories
]

fig = plt.figure(figsize=(18, 6))
gs  = gridspec.GridSpec(1, 3, figure=fig, wspace=0.50)

ax1 = fig.add_subplot(gs[0])
sc.pl.umap(adata, color="cell_type", ax=ax1, show=False,
           title="Cell Types", legend_loc="right margin", legend_fontsize=7.5,
           palette=CT_PALETTE)

ax2 = fig.add_subplot(gs[1])
sc.pl.umap(adata, color="label", ax=ax2, show=False,
           title="Condition",
           palette={"healthy": "#4DBBD5", "patient": "#E64B35"})

ax3 = fig.add_subplot(gs[2])
sc.pl.umap(adata, color="dataset", ax=ax3, show=False,
           title="Dataset", legend_fontsize=8)

fig.suptitle("Human Skin scRNA-seq: 35 Donors, 93K Cells (Harmony-integrated)",
             fontsize=14, fontweight="bold", y=1.01)
strengthen_figure_text(fig)
plt.savefig(OUT_DIR / "fig1_umap_overview.png", dpi=300, bbox_inches="tight")
plt.close()
print("  Saved: fig1_umap_overview.png")

# ─── 4. FIGURE 2: MARKER DOT PLOT ────────────────────────────────────────────
print("\n=== 4. Figure 2 — Marker dot plot ===")

marker_plot_genes = {
    "Keratinocyte_basal":  ["KRT14", "KRT5"],
    "Keratinocyte_supra":  ["KRT1", "KRT10"],
    "Melanocyte":          ["PMEL", "MLANA"],
    "Fibroblast":          ["COL1A1", "DCN"],
    "CD8_T":               ["CD8A", "GZMK"],
    "CD4_T":               ["CD4", "IL7R"],
    "Treg":                ["FOXP3", "IL2RA"],
    "NK":                  ["GNLY", "KLRD1"],
    "Macrophage":          ["CD68", "LYZ"],
    "Dendritic":           ["CD1C", "LAMP3"],
    "Endothelial":         ["PECAM1", "VWF"],
    "Mast":                ["TPSAB1", "CPA3"],
    "Plasma_B":            ["MZB1", "IGKC"],
}
plot_genes = []
for g_list in marker_plot_genes.values():
    plot_genes += [g for g in g_list if g in adata.var_names]
plot_genes = list(dict.fromkeys(plot_genes))  # deduplicate, preserve order

ct_order = [ct for ct in marker_plot_genes if ct in adata.obs["cell_type"].unique()]

fig, ax = plt.subplots(figsize=(len(plot_genes) * 0.55 + 1, len(ct_order) * 0.45 + 1))
sc.pl.dotplot(adata, plot_genes, groupby="cell_type",
              categories_order=ct_order,
              standard_scale="var", ax=ax, show=False,
              title="Cell Type Marker Expression")
strengthen_figure_text(fig)
plt.savefig(OUT_DIR / "fig2_marker_dotplot.png", dpi=300, bbox_inches="tight")
plt.close()
print("  Saved: fig2_marker_dotplot.png")

# ─── 5. FIGURE 3: CELL TYPE COMPOSITION ──────────────────────────────────────
print("\n=== 5. Figure 3 — Cell type composition ===")

comp = adata.obs.groupby(["donor", "cell_type"]).size().unstack(fill_value=0)
comp_pct = comp.div(comp.sum(axis=1), axis=0) * 100

donor_label = adata.obs.groupby("donor")["label"].first()
comp_pct["label"] = donor_label

# Mean composition per condition
mean_h = comp_pct[comp_pct["label"]=="healthy"].drop("label", axis=1).mean()
mean_p = comp_pct[comp_pct["label"]=="patient"].drop("label", axis=1).mean()
comp_mean = pd.DataFrame({"Healthy": mean_h, "Patient": mean_p}).fillna(0)
comp_mean = comp_mean.loc[comp_mean.sum(axis=1) > 0.1]

fig, axes = plt.subplots(1, 2, figsize=(16, 6))

# Stacked bar: per-donor composition
ax = axes[0]
donors_h = [d for d in comp_pct.index if donor_label[d]=="healthy"]
donors_p = [d for d in comp_pct.index if donor_label[d]=="patient"]
donor_order = donors_h + donors_p
plot_comp = comp_pct.loc[donor_order].drop("label", axis=1)
bottom = np.zeros(len(donor_order))
for ct in plot_comp.columns:
    color = CT_PALETTE.get(ct, "#AAAAAA")
    ax.bar(range(len(donor_order)), plot_comp[ct], bottom=bottom,
           color=color, label=ct, width=0.85)
    bottom += plot_comp[ct].values
ax.axvline(len(donors_h) - 0.5, color="black", lw=1.5, ls="--")
ax.set_xticks(range(len(donor_order)))
ax.set_xticklabels(donor_order, rotation=45, ha="right", fontsize=7)
ax.set_ylabel("Cell type proportion (%)")
ax.set_title("Per-donor Cell Type Composition")
ax.text(len(donors_h)/2 - 0.5, 103, "Healthy", ha="center", fontsize=9, color="#4DBBD5")
ax.text(len(donors_h) + len(donors_p)/2 - 0.5, 103, "Patient", ha="center", fontsize=9, color="#E64B35")

# Grouped bar: mean ± sem per condition
ax2 = axes[1]
ct_list = comp_mean.index.tolist()
x = np.arange(len(ct_list))
w = 0.35
sem_h = comp_pct[comp_pct["label"]=="healthy"].drop("label",axis=1)[ct_list].sem()
sem_p = comp_pct[comp_pct["label"]=="patient"].drop("label",axis=1)[ct_list].sem()
ax2.bar(x - w/2, comp_mean["Healthy"], w, yerr=sem_h, color="#4DBBD5",
        alpha=0.85, label="Healthy", capsize=3)
ax2.bar(x + w/2, comp_mean["Patient"], w, yerr=sem_p, color="#E64B35",
        alpha=0.85, label="Patient", capsize=3)
ax2.set_xticks(x)
ax2.set_xticklabels(ct_list, rotation=40, ha="right", fontsize=8)
ax2.set_ylabel("Mean proportion (%)")
ax2.set_title("Cell Type Proportion: Healthy vs Patient")
ax2.legend()

plt.tight_layout()
strengthen_figure_text(fig)
plt.savefig(OUT_DIR / "fig3_composition.png", dpi=300, bbox_inches="tight")
plt.close()
print("  Saved: fig3_composition.png")

# Statistical tests for all annotated cell types, with BH correction across one family.
from scipy.stats import mannwhitneyu
print("\n  Composition tests (two-sided Mann-Whitney; BH across all cell types):")
composition_rows = []
composition_types = [column for column in comp_pct.columns if column != "label"]
for ct in composition_types:
    h_vals = comp_pct.loc[comp_pct["label"]=="healthy", ct].values
    p_vals = comp_pct.loc[comp_pct["label"]=="patient", ct].values
    if len(h_vals) > 1 and len(p_vals) > 1:
        statistic, pval = mannwhitneyu(h_vals, p_vals, alternative="two-sided")
        composition_rows.append(
            {
                "cell_type": ct,
                "healthy_mean_percent": h_vals.mean(),
                "patient_mean_percent": p_vals.mean(),
                "mann_whitney_u": statistic,
                "p_raw": pval,
            }
        )

composition_stats = pd.DataFrame(composition_rows)
composition_stats["q_bh"] = multipletests(
    composition_stats["p_raw"], method="fdr_bh"
)[1]
composition_stats["significant_q_lt_0_05"] = composition_stats["q_bh"] < 0.05
composition_stats = composition_stats.sort_values(["q_bh", "p_raw", "cell_type"])
composition_stats.to_csv(OUT_DIR / "cell_type_composition_statistics.csv", index=False)
print(composition_stats.to_string(index=False))

# ─── 6. FIGURE 4: IFN-γ SIGNATURE SCORE ─────────────────────────────────────
print("\n=== 6. Figure 4 — IFN-γ signature ===")

# Hallmark IFN-γ core genes (manually curated, no internet needed)
IFN_GAMMA_GENES = [
    "CXCL9","CXCL10","CXCL11","GBP1","GBP2","GBP4","GBP5",
    "IDO1","IRF1","WARS","CIITA","HLA-DRA","HLA-DRB1",
    "STAT1","STAT2","ISG15","IFIT1","IFIT2","IFIT3",
    "MX1","OAS1","RSAD2","IFI44L","HERC5","CMPK2","TYMP","RARRES3"
]
IFN_ALPHA_GENES = [
    "ISG15","IFIT1","IFIT2","IFIT3","MX1","OAS1","OAS2","OAS3",
    "RSAD2","IFI44L","HERC5","CMPK2","OASL","DDX58","IFIH1"
]
CYTOTOX_GENES = ["GZMA","GZMB","GZMK","GZMM","PRF1","NKG7","GNLY","FASLG"]

for name, genes in [("IFN_gamma", IFN_GAMMA_GENES),
                     ("IFN_alpha", IFN_ALPHA_GENES),
                     ("Cytotoxic", CYTOTOX_GENES)]:
    present = [g for g in genes if g in adata.var_names]
    sc.tl.score_genes(adata, present, score_name=name, use_raw=False)
    print(f"  {name}: {len(present)}/{len(genes)} genes found")

fig, axes = plt.subplots(2, 3, figsize=(18, 10))

for col, score_key, title in [
    (0, "IFN_gamma", "IFN-γ Signature"),
    (1, "IFN_alpha", "IFN-α Signature"),
    (2, "Cytotoxic",  "Cytotoxic Score")
]:
    # UMAP colored by score
    sc.pl.umap(adata, color=score_key, ax=axes[0, col], show=False,
               title=title, cmap="RdYlBu_r", vmin=-0.3, vmax=1.5)

    # Violin: score per cell type, split by condition
    ax = axes[1, col]
    score_df = adata.obs[["cell_type", "label", score_key]].copy()
    # Focus on immune + melanocyte cell types
    focus_cts = ["CD8_T","CD4_T","NK","Macrophage","Dendritic","Melanocyte",
                 "Keratinocyte_basal","Fibroblast"]
    focus_cts = [c for c in focus_cts if c in score_df["cell_type"].unique()]
    plot_df = score_df[score_df["cell_type"].isin(focus_cts)]
    sns.violinplot(data=plot_df, x="cell_type", y=score_key, hue="label",
                   split=True, inner="quart", scale="width",
                   palette={"healthy":"#4DBBD5","patient":"#E64B35"},
                   ax=ax, linewidth=0.5)
    ax.set_xticklabels(ax.get_xticklabels(), rotation=35, ha="right", fontsize=8)
    ax.set_title(f"{title} by Cell Type")
    ax.set_xlabel(""); ax.legend(fontsize=7)
    ax.set_ylim(-1, 3)

plt.suptitle("IFN Signatures and Cytotoxic Activity: Healthy vs Vitiligo",
             fontsize=14, fontweight="bold", y=1.01)
plt.tight_layout()
strengthen_figure_text(fig)
plt.savefig(OUT_DIR / "fig4_ifn_scores.png", dpi=300, bbox_inches="tight")
plt.close()
print("  Saved: fig4_ifn_scores.png")

# ─── 7. FIGURE 5: KEY GENES IN CELL TYPE CONTEXT ─────────────────────────────
print("\n=== 7. Figure 5 — Key genes in cell type context ===")

KEY_GENES = ["CXCL9","CXCL10","CRYM","MLANA","GZMK","PRF1","ZNF683","KIR2DL4"]
KEY_GENES = [g for g in KEY_GENES if g in adata.var_names]

focus_cts = ["CD8_T","CD4_T","NK","Macrophage","Dendritic",
             "Melanocyte","Keratinocyte_basal","Fibroblast","Plasma_B"]
focus_cts = [c for c in focus_cts if c in adata.obs["cell_type"].unique()]
adata_focus = adata[adata.obs["cell_type"].isin(focus_cts)].copy()

fig, ax = plt.subplots(figsize=(len(KEY_GENES) * 0.9 + 1, len(focus_cts) * 0.6 + 1))
sc.pl.dotplot(adata_focus, KEY_GENES, groupby="cell_type",
              categories_order=focus_cts,
              standard_scale="var", ax=ax, show=False,
              title="Key Vitiligo Genes across Cell Types")
strengthen_figure_text(fig)
plt.savefig(OUT_DIR / "fig5_keygenes_celltype.png", dpi=300, bbox_inches="tight")
plt.close()
print("  Saved: fig5_keygenes_celltype.png")

# ─── 8. FIGURE 6: CD8 T CELL FOCUS ──────────────────────────────────────────
print("\n=== 8. Figure 6 — CD8+ T cell deep analysis ===")

cd8 = adata[adata.obs["cell_type"] == "CD8_T"].copy()
if cd8.n_obs > 50:
    print(f"  CD8+ T cells: {cd8.n_obs} ({(cd8.obs['label']=='patient').mean()*100:.1f}% from patient)")

    sc.pp.neighbors(cd8, use_rep="X_pca_harmony", n_neighbors=10)
    sc.tl.umap(cd8)
    sc.tl.leiden(cd8, resolution=0.4, random_state=42)

    # Score Trm and effector states
    TRM_GENES  = ["ZNF683","ITGAE","CD69","CXCR6","RBPJ","PRDM1"]
    EFF_GENES  = ["GZMK","GZMA","PRF1","NKG7","GNLY","CX3CR1","FGFBP2"]
    EXHAUS_GENES = ["PDCD1","HAVCR2","TIGIT","LAG3","TOX","NR4A1"]

    for nm, gl in [("Trm_score",TRM_GENES),("Effector_score",EFF_GENES),
                   ("Exhaustion_score",EXHAUS_GENES)]:
        present = [g for g in gl if g in cd8.var_names]
        if present:
            sc.tl.score_genes(cd8, present, score_name=nm, use_raw=False)

    fig, axes = plt.subplots(2, 3, figsize=(16, 10))
    sc.pl.umap(cd8, color="label",   ax=axes[0,0], show=False, title="Condition",
               palette={"healthy":"#4DBBD5","patient":"#E64B35"})
    sc.pl.umap(cd8, color="leiden",  ax=axes[0,1], show=False, title="Subcluster")
    sc.pl.umap(cd8, color="dataset", ax=axes[0,2], show=False, title="Dataset")

    for col, sc_key, title in [(0,"Trm_score","Trm Score"),
                                (1,"Effector_score","Effector Score"),
                                (2,"Exhaustion_score","Exhaustion Score")]:
        if sc_key in cd8.obs.columns:
            sc.pl.umap(cd8, color=sc_key, ax=axes[1,col], show=False,
                       title=title, cmap="RdYlBu_r")

    plt.suptitle("CD8+ T Cell Landscape in Vitiligo Skin",
                 fontsize=14, fontweight="bold", y=1.01)
    plt.tight_layout()
    strengthen_figure_text(fig)
    plt.savefig(OUT_DIR / "fig6_cd8_analysis.png", dpi=300, bbox_inches="tight")
    plt.close()
    print("  Saved: fig6_cd8_analysis.png")

    # CD8 proportion per donor
    cd8_pct = comp_pct["CD8_T"].copy() if "CD8_T" in comp_pct.columns else None
    if cd8_pct is not None:
        fig, ax = plt.subplots(figsize=(7, 4))
        h_vals = cd8_pct[donor_label == "healthy"].values
        p_vals = cd8_pct[donor_label == "patient"].values
        ax.boxplot([h_vals, p_vals], labels=["Healthy","Patient"],
                   patch_artist=True,
                   boxprops=dict(facecolor="#E8F4FD"),
                   medianprops=dict(color="navy"))
        from scipy.stats import mannwhitneyu
        _, pval = mannwhitneyu(h_vals, p_vals, alternative="two-sided")
        ax.set_title(f"CD8+ T Cell Proportion  (p={pval:.3f})")
        ax.set_ylabel("% of total cells")
        plt.tight_layout()
        strengthen_figure_text(fig)
        plt.savefig(OUT_DIR / "fig6b_cd8_proportion.png", dpi=300, bbox_inches="tight")
        plt.close()
        print(f"  CD8 proportion: Healthy={h_vals.mean():.1f}%  Patient={p_vals.mean():.1f}%  p={pval:.3f}")

# ─── 9. SAVE ANNOTATED ADATA ─────────────────────────────────────────────────
adata.obs[["donor","label","dataset","leiden","cell_type",
           "IFN_gamma","IFN_alpha","Cytotoxic"]].to_csv(
    OUT_DIR / "cell_metadata.csv")
adata.write_h5ad(OUT_DIR / "adata_annotated.h5ad")
print("\n  Saved: adata_annotated.h5ad  +  cell_metadata.csv")

# ─── 10. SUMMARY ─────────────────────────────────────────────────────────────
print("\n" + "="*60)
print("CELL TYPE ANNOTATION COMPLETE")
print(f"Clusters identified: {adata.obs['leiden'].nunique()}")
print(f"Cell types annotated: {adata.obs['cell_type'].nunique()}")
print("\nCell type counts:")
print(adata.obs["cell_type"].value_counts().to_string())
print("\nOutput figures:")
for f in sorted(OUT_DIR.glob("fig*.png")):
    print(f"  {f.name}")
print("="*60)
