"""Fair donor-level baseline comparison for the vitiligo scRNA-seq study.

All methods use the same five outer donor folds (StratifiedKFold, seed 42).
Classical baselines receive the mean of each donor's Harmony-corrected 50-PC
cell embeddings. Hyperparameters are selected only within each outer training
fold by three-fold stratified cross-validation. Mean-pooling MIL differs from
attention MIL only in the pooling operator.
"""

from __future__ import annotations

import json
import os
import random
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
import sklearn
import torch
import torch.nn as nn
import torch.nn.functional as F
import xgboost
from sklearn.base import clone
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, roc_auc_score
from sklearn.model_selection import GridSearchCV, StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from statsmodels.stats.proportion import proportion_confint
from xgboost import XGBClassifier


ROOT = Path(
    os.environ.get("VITILIGO_PROJECT_ROOT", Path(__file__).resolve().parents[1])
).resolve()
ADATA_PATH = ROOT / "output" / "adata_harmony.h5ad"
OUT_DIR = ROOT / "output" / "baseline_comparison"
OUT_DIR.mkdir(parents=True, exist_ok=True)

OUTER_SEED = 42
MODEL_SEED = 2026
N_BOOT = 5000
N_EPOCHS = 100
INPUT_DIM = 50
HIDDEN_DIM = 128
ATTN_DIM = 64


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


class GeneGating(nn.Module):
    def __init__(self, in_dim: int):
        super().__init__()
        self.w = nn.Parameter(torch.ones(in_dim))

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        gate = torch.sigmoid(self.w)
        return x * gate, gate


class DonorMIL(nn.Module):
    def __init__(self, pooling: str):
        super().__init__()
        if pooling not in {"attention", "mean"}:
            raise ValueError(f"Unsupported pooling: {pooling}")
        self.pooling = pooling
        self.gating = GeneGating(INPUT_DIM)
        self.encoder = nn.Sequential(
            nn.Linear(INPUT_DIM, HIDDEN_DIM),
            nn.LayerNorm(HIDDEN_DIM),
            nn.GELU(),
            nn.Linear(HIDDEN_DIM, HIDDEN_DIM),
            nn.GELU(),
        )
        if pooling == "attention":
            self.attn_v = nn.Linear(HIDDEN_DIM, ATTN_DIM)
            self.attn_u = nn.Linear(HIDDEN_DIM, ATTN_DIM)
            self.attn_w = nn.Linear(ATTN_DIM, 1)
        self.head = nn.Linear(HIDDEN_DIM, 1)

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        x_gated, gate = self.gating(x)
        h = self.encoder(x_gated)
        if self.pooling == "attention":
            scores = self.attn_w(
                torch.tanh(self.attn_v(h)) * torch.sigmoid(self.attn_u(h))
            )
            weights = torch.softmax(scores, dim=0)
            z = (weights * h).sum(dim=0, keepdim=True)
        else:
            z = h.mean(dim=0, keepdim=True)
        return self.head(z).squeeze(), gate


def fit_mil(
    pooling: str,
    train_donors: list[str],
    test_donors: list[str],
    donor_x: dict[str, np.ndarray],
    labels: dict[str, int],
    seed: int,
) -> np.ndarray:
    seed_everything(seed)
    model = DonorMIL(pooling)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=N_EPOCHS)

    for _ in range(N_EPOCHS):
        model.train()
        for donor in train_donors:
            x = torch.as_tensor(donor_x[donor], dtype=torch.float32)
            y = torch.tensor(float(labels[donor]))
            optimizer.zero_grad()
            logit, gate = model(x)
            loss = F.binary_cross_entropy_with_logits(logit, y)
            loss = loss + 1e-3 * gate.abs().sum()
            loss.backward()
            optimizer.step()
        scheduler.step()

    model.eval()
    probabilities = []
    with torch.no_grad():
        for donor in test_donors:
            x = torch.as_tensor(donor_x[donor], dtype=torch.float32)
            logit, _ = model(x)
            probabilities.append(torch.sigmoid(logit).item())
    return np.asarray(probabilities)


def stratified_auc_ci(
    y_true: np.ndarray, probabilities: np.ndarray, rng: np.random.Generator
) -> tuple[float, float]:
    positive = np.flatnonzero(y_true == 1)
    negative = np.flatnonzero(y_true == 0)
    values = np.empty(N_BOOT, dtype=float)
    for i in range(N_BOOT):
        idx = np.concatenate(
            [
                rng.choice(positive, len(positive), replace=True),
                rng.choice(negative, len(negative), replace=True),
            ]
        )
        values[i] = roc_auc_score(y_true[idx], probabilities[idx])
    return tuple(np.quantile(values, [0.025, 0.975]))


def classical_models(train_y: np.ndarray, seed: int):
    scale_pos_weight = float((train_y == 0).sum() / max((train_y == 1).sum(), 1))
    return {
        "Logistic regression": (
            Pipeline(
                [
                    ("scale", StandardScaler()),
                    (
                        "model",
                        LogisticRegression(
                            penalty="l2",
                            class_weight="balanced",
                            solver="liblinear",
                            max_iter=5000,
                            random_state=seed,
                        ),
                    ),
                ]
            ),
            {"model__C": [0.01, 0.1, 1.0, 10.0]},
        ),
        "Random forest": (
            RandomForestClassifier(
                n_estimators=500,
                class_weight="balanced",
                random_state=seed,
                n_jobs=1,
            ),
            {
                "max_depth": [2, 4, None],
                "min_samples_leaf": [1, 2, 4],
                "max_features": ["sqrt", 0.5],
            },
        ),
        "XGBoost": (
            XGBClassifier(
                objective="binary:logistic",
                eval_metric="logloss",
                reg_lambda=1.0,
                subsample=0.8,
                colsample_bytree=0.8,
                scale_pos_weight=scale_pos_weight,
                random_state=seed,
                n_jobs=1,
            ),
            {
                "n_estimators": [100, 300],
                "max_depth": [1, 2, 3],
                "learning_rate": [0.03, 0.1],
            },
        ),
    }


def main() -> None:
    print(f"Loading {ADATA_PATH}", flush=True)
    adata = ad.read_h5ad(ADATA_PATH, backed="r")
    obs = adata.obs[["donor", "label", "dataset"]].copy()
    embedding = np.asarray(adata.obsm["X_pca_harmony"], dtype=np.float32)

    donors = obs["donor"].drop_duplicates().astype(str).tolist()
    labels = {
        donor: int(obs.loc[obs["donor"].astype(str) == donor, "label"].iloc[0] == "patient")
        for donor in donors
    }
    datasets = {
        donor: str(obs.loc[obs["donor"].astype(str) == donor, "dataset"].iloc[0])
        for donor in donors
    }
    donor_values = obs["donor"].astype(str).to_numpy()
    donor_x = {donor: embedding[donor_values == donor] for donor in donors}
    donor_mean = np.vstack([donor_x[donor].mean(axis=0) for donor in donors])
    y = np.asarray([labels[donor] for donor in donors], dtype=int)

    outer = StratifiedKFold(n_splits=5, shuffle=True, random_state=OUTER_SEED)
    methods = [
        "Logistic regression",
        "Random forest",
        "XGBoost",
        "Mean-pooling MIL",
        "Gated-attention MIL",
    ]
    oof = {method: np.full(len(donors), np.nan) for method in methods}
    fold_rows: list[dict] = []
    parameter_rows: list[dict] = []

    for fold, (train_idx, test_idx) in enumerate(outer.split(donors, y), start=1):
        seed = MODEL_SEED + fold
        train_donors = [donors[i] for i in train_idx]
        test_donors = [donors[i] for i in test_idx]
        train_y, test_y = y[train_idx], y[test_idx]
        inner = StratifiedKFold(n_splits=3, shuffle=True, random_state=seed)
        print(f"Fold {fold}: {len(train_idx)} train / {len(test_idx)} test", flush=True)

        for method, (estimator, grid) in classical_models(train_y, seed).items():
            search = GridSearchCV(
                clone(estimator),
                param_grid=grid,
                scoring="roc_auc",
                cv=inner,
                refit=True,
                n_jobs=1,
                error_score="raise",
            )
            search.fit(donor_mean[train_idx], train_y)
            probabilities = search.predict_proba(donor_mean[test_idx])[:, 1]
            oof[method][test_idx] = probabilities
            parameter_rows.append(
                {
                    "fold": fold,
                    "method": method,
                    "inner_cv_auc": search.best_score_,
                    "selected_parameters": json.dumps(search.best_params_, sort_keys=True),
                }
            )
            print(f"  {method}: inner AUC={search.best_score_:.3f}", flush=True)

        for method, pooling in [
            ("Mean-pooling MIL", "mean"),
            ("Gated-attention MIL", "attention"),
        ]:
            probabilities = fit_mil(
                pooling, train_donors, test_donors, donor_x, labels, seed
            )
            oof[method][test_idx] = probabilities
            print(f"  {method}: fold complete", flush=True)

        for method in methods:
            fold_prob = oof[method][test_idx]
            fold_rows.append(
                {
                    "fold": fold,
                    "method": method,
                    "n_test": len(test_idx),
                    "accuracy": accuracy_score(test_y, fold_prob >= 0.5),
                    "auc": roc_auc_score(test_y, fold_prob),
                }
            )

    prediction_rows = []
    for i, donor in enumerate(donors):
        for method in methods:
            prediction_rows.append(
                {
                    "donor": donor,
                    "dataset": datasets[donor],
                    "true_label": y[i],
                    "method": method,
                    "predicted_probability": oof[method][i],
                    "predicted_label": int(oof[method][i] >= 0.5),
                }
            )
    prediction_df = pd.DataFrame(prediction_rows)

    rng = np.random.default_rng(OUTER_SEED)
    summary_rows = []
    for method in methods:
        probabilities = oof[method]
        predictions = (probabilities >= 0.5).astype(int)
        accuracy = accuracy_score(y, predictions)
        auc = roc_auc_score(y, probabilities)
        auc_low, auc_high = stratified_auc_ci(y, probabilities, rng)
        acc_low, acc_high = proportion_confint(
            int((predictions == y).sum()), len(y), alpha=0.05, method="wilson"
        )
        cm = confusion_matrix(y, predictions, labels=[0, 1])
        summary_rows.append(
            {
                "method": method,
                "accuracy": accuracy,
                "accuracy_ci_low": acc_low,
                "accuracy_ci_high": acc_high,
                "auc": auc,
                "auc_ci_low": auc_low,
                "auc_ci_high": auc_high,
                "true_negative": int(cm[0, 0]),
                "false_positive": int(cm[0, 1]),
                "false_negative": int(cm[1, 0]),
                "true_positive": int(cm[1, 1]),
            }
        )
    summary_df = pd.DataFrame(summary_rows).sort_values("auc", ascending=False)
    fold_df = pd.DataFrame(fold_rows)
    parameter_df = pd.DataFrame(parameter_rows)

    summary_df.to_csv(OUT_DIR / "baseline_comparison_summary.csv", index=False)
    prediction_df.to_csv(OUT_DIR / "baseline_oof_predictions.csv", index=False)
    fold_df.to_csv(OUT_DIR / "baseline_fold_metrics.csv", index=False)
    parameter_df.to_csv(OUT_DIR / "baseline_selected_parameters.csv", index=False)
    with pd.ExcelWriter(OUT_DIR / "Table_S12_baseline_comparison.xlsx") as writer:
        summary_df.to_excel(writer, sheet_name="Summary", index=False)
        prediction_df.to_excel(writer, sheet_name="OOF_predictions", index=False)
        fold_df.to_excel(writer, sheet_name="Fold_metrics", index=False)
        parameter_df.to_excel(writer, sheet_name="Selected_parameters", index=False)

    metadata = {
        "input": str(ADATA_PATH),
        "outer_cv": "5-fold stratified donor-level CV",
        "outer_seed": OUTER_SEED,
        "model_seed_base": MODEL_SEED,
        "inner_cv": "3-fold stratified donor-level CV for classical baselines only",
        "epochs": N_EPOCHS,
        "n_donors": len(donors),
        "n_healthy": int((y == 0).sum()),
        "n_patient": int((y == 1).sum()),
        "numpy_version": np.__version__,
        "pandas_version": pd.__version__,
        "scikit_learn_version": sklearn.__version__,
        "torch_version": torch.__version__,
        "xgboost_version": xgboost.__version__,
    }
    (OUT_DIR / "benchmark_metadata.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )
    print("\nFinal donor-level out-of-fold results", flush=True)
    print(summary_df.to_string(index=False), flush=True)


if __name__ == "__main__":
    torch.set_num_threads(4)
    main()
