"""Exact global validation tests for the held-out GSE298871 cohort.

This analysis uses only the frozen-model predictions and the ten donor-level
endpoints defined before group testing.  It does not refit the classifier,
change endpoint definitions, or select a favourable subset of endpoints.
"""

from __future__ import annotations

from itertools import combinations
import os
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score


PROJECT_ROOT = Path(
    os.environ.get("VITILIGO_PROJECT_ROOT", Path(__file__).resolve().parents[1])
).resolve()
ANALYSIS_DIR = PROJECT_ROOT / "output" / "external_validation"
OUTPUT_FILE = ANALYSIS_DIR / "Table_S11_external_global_validation.csv"

ENDPOINT_DIRECTIONS = {
    "ifn_all": "up",
    "ifn_macrophage": "up",
    "ifn_keratinocyte": "up",
    "cytotoxic_cd8": "up",
    "trm_cd8": "up",
    "prop_macrophage": "up",
    "prop_fibroblast": "down",
    "prop_endothelial": "down",
    "prop_cd8": "up",
    "prop_melanocyte": "down",
}


def balanced_label_permutations(n_samples: int, n_positive: int):
    """Yield every label allocation with the observed group sizes."""
    for positive_indices in combinations(range(n_samples), n_positive):
        labels = np.zeros(n_samples, dtype=int)
        labels[list(positive_indices)] = 1
        yield labels


def mean_direction_oriented_auc(
    features: pd.DataFrame,
    labels: np.ndarray,
) -> float:
    """Average endpoint AUC after orienting each endpoint to its expected direction."""
    endpoint_aucs = []
    for endpoint, direction in ENDPOINT_DIRECTIONS.items():
        observed = features[endpoint].notna().to_numpy()
        endpoint_labels = labels[observed]
        if np.unique(endpoint_labels).size != 2:
            return np.nan
        values = features.loc[observed, endpoint].to_numpy(dtype=float)
        if direction == "down":
            values = -values
        endpoint_aucs.append(roc_auc_score(endpoint_labels, values))
    return float(np.mean(endpoint_aucs))


def exact_upper_tail_p(observed: float, null_statistics: np.ndarray) -> float:
    """Return the exhaustive randomisation-test upper-tail probability."""
    valid = null_statistics[np.isfinite(null_statistics)]
    return float(np.mean(valid >= observed))


def main() -> None:
    features = pd.read_csv(
        ANALYSIS_DIR / "gse298871_primary_validation_features.csv"
    )
    predictions = pd.read_csv(
        ANALYSIS_DIR / "gse298871_external_predictions.csv"
    )

    feature_labels = features["label"].eq("patient").to_numpy(dtype=int)
    prediction_labels = predictions["true_label"].to_numpy(dtype=int)
    n_positive = int(feature_labels.sum())
    permutations = list(
        balanced_label_permutations(len(feature_labels), n_positive)
    )

    observed_global_auc = mean_direction_oriented_auc(features, feature_labels)
    global_null = np.asarray(
        [
            mean_direction_oriented_auc(features, permuted_labels)
            for permuted_labels in permutations
        ]
    )

    probabilities = predictions["predicted_probability"].to_numpy(dtype=float)
    observed_classifier_auc = roc_auc_score(prediction_labels, probabilities)
    classifier_null = np.asarray(
        [
            roc_auc_score(permuted_labels, probabilities)
            for permuted_labels in permutations
        ]
    )

    rows = [
        {
            "test": "Frozen eight-feature classifier",
            "statistic": "AUC",
            "estimate": observed_classifier_auc,
            "alternative": "AUC > 0.5",
            "exact_p_value": exact_upper_tail_p(
                observed_classifier_auc, classifier_null
            ),
            "n_healthy": int((prediction_labels == 0).sum()),
            "n_patient": int((prediction_labels == 1).sum()),
            "label_permutations": len(permutations),
            "interpretation": (
                "Independent discrimination by the discovery-trained frozen model"
            ),
        },
        {
            "test": "Ten-endpoint directional omnibus",
            "statistic": "Mean direction-oriented AUC",
            "estimate": observed_global_auc,
            "alternative": "Mean direction-oriented AUC > 0.5",
            "exact_p_value": exact_upper_tail_p(
                observed_global_auc, global_null
            ),
            "n_healthy": int((feature_labels == 0).sum()),
            "n_patient": int((feature_labels == 1).sum()),
            "label_permutations": len(permutations),
            "interpretation": (
                "Collective directional concordance; not significance of every endpoint"
            ),
        },
    ]
    result = pd.DataFrame(rows)
    result.to_csv(OUTPUT_FILE, index=False)
    print(result.to_string(index=False))
    print(f"\nWrote {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
