"""
Independent within-cohort validation using GSE298871.

Primary validation uses one skin sample per independent donor:
six healthy skin donors and six lesional vitiligo donors. Five paired
non-lesional samples are retained only for within-patient sensitivity analyses.
The script deliberately does not merge these data into model training.
"""

from __future__ import annotations

import gzip
import json
import os
from pathlib import Path

import anndata as ad
from anndata.utils import make_index_unique
import matplotlib
import numpy as np
import pandas as pd
import scanpy as sc
import seaborn as sns
from matplotlib import pyplot as plt
from matplotlib.lines import Line2D
from scipy.io import mmread
from scipy.stats import mannwhitneyu, wilcoxon
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    roc_auc_score,
)
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from statsmodels.stats.proportion import proportion_confint
from statsmodels.stats.multitest import multipletests

matplotlib.use("Agg")

ROOT = Path(
    os.environ.get("VITILIGO_PROJECT_ROOT", Path(__file__).resolve().parents[1])
).resolve()
DATA_DIR = ROOT / "data" / "GSE298871"
OUT_DIR = ROOT / "output" / "external_validation"
OUT_DIR.mkdir(parents=True, exist_ok=True)

MANIFEST_PATH = Path(
    os.environ.get(
        "GSE298871_MANIFEST",
        ROOT / "config" / "sample_manifest_GSE298871.csv",
    )
)
MANIFEST = pd.read_csv(MANIFEST_PATH, dtype={"primary_validation": int})

MARKERS = {
    "Keratinocyte_basal": ["KRT14", "KRT5", "TP63", "COL17A1", "ITGA6"],
    "Keratinocyte_supra": ["KRT1", "KRT10", "KRTDAP", "FLG", "LORICRIN"],
    "Melanocyte": ["PMEL", "MLANA", "DCT", "TYRP1", "MITF"],
    "Fibroblast": ["COL1A1", "COL1A2", "DCN", "LUM", "PDGFRA"],
    "CD8_T": ["CD3D", "CD8A", "GZMK", "GZMA", "PRF1", "NKG7"],
    "CD4_T": ["CD3D", "CD4", "IL7R", "MAL"],
    "Treg": ["FOXP3", "IL2RA", "CTLA4", "IKZF2"],
    "NK": ["GNLY", "NKG7", "KLRD1", "KIR2DL4", "KLRC2"],
    "Macrophage": ["CD68", "CD14", "LYZ", "MRC1", "CSF1R"],
    "Dendritic": ["CLEC9A", "CD1C", "LAMP3", "CCR7", "ITGAX"],
    "Endothelial": ["PECAM1", "VWF", "CDH5", "CLDN5"],
    "Mast": ["TPSAB1", "CPA3", "KIT"],
    "Plasma_B": ["MZB1", "IGHG1", "IGHG4", "IGKC", "MS4A1"],
}

IFN_GAMMA_GENES = [
    "CXCL9", "CXCL10", "CXCL11", "GBP1", "GBP2", "GBP4", "GBP5",
    "IDO1", "IRF1", "WARS", "CIITA", "HLA-DRA", "HLA-DRB1",
    "STAT1", "STAT2", "ISG15", "IFIT1", "IFIT2", "IFIT3",
    "OAS1", "OAS2", "OAS3", "MX1", "MX2", "PSMB8", "PSMB9", "TAP1",
]
CYTOTOXIC_GENES = ["GZMA", "GZMB", "GZMK", "GZMM", "PRF1", "NKG7", "GNLY", "FASLG"]
TRM_GENES = ["ZNF683", "ITGAE", "CD69", "CXCR6", "RBPJ", "PRDM1"]

CLASSIFIER_FEATURES = [
    "ifn_all",
    "ifn_macrophage",
    "ifn_keratinocyte",
    "cytotoxic_cd8",
    "prop_macrophage",
    "prop_fibroblast",
    "prop_endothelial",
    "prop_cd8",
]

ENDPOINT_DIRECTIONS = {
    "ifn_all": "up",
    "ifn_macrophage": "up",
    "ifn_keratinocyte": "up",
    "cytotoxic_cd8": "up",
    "trm_cd8": "up",
    "prop_macrophage": "up",
    "prop_fibroblast": "down",
    "prop_endothelial": "down",
    "prop_cd8": "up",
    "prop_melanocyte": "down",
}

GENE_TARGETS = {
    "CXCL9_macrophage": ("CXCL9", ["Macrophage"]),
    "CXCL10_macrophage": ("CXCL10", ["Macrophage"]),
    "ZNF683_cd8": ("ZNF683", ["CD8_T"]),
    "GZMK_cd8": ("GZMK", ["CD8_T"]),
    "PRF1_cd8": ("PRF1", ["CD8_T"]),
    "CRYM_melanocyte": ("CRYM", ["Melanocyte"]),
}


def locate_triplet(row: pd.Series) -> tuple[Path, Path, Path]:
    prefix = f"{row.geo_accession}_{row.sample_id}"
    return (
        DATA_DIR / f"{prefix}_matrix.mtx.gz",
        DATA_DIR / f"{prefix}_features.tsv.gz",
        DATA_DIR / f"{prefix}_barcodes.tsv.gz",
    )


def read_sample(row: pd.Series) -> ad.AnnData:
    matrix_file, feature_file, barcode_file = locate_triplet(row)
    for path in (matrix_file, feature_file, barcode_file):
        if not path.exists():
            raise FileNotFoundError(path)

    with gzip.open(matrix_file, "rb") as handle:
        matrix = mmread(handle).tocsr().T
    features = pd.read_csv(feature_file, sep="\t", header=None)
    barcodes = pd.read_csv(barcode_file, sep="\t", header=None)[0].astype(str)
    gene_names = features[1].astype(str) if features.shape[1] > 1 else features[0].astype(str)
    gene_names = make_index_unique(pd.Index(gene_names))
    gene_names.name = None

    obs_names = [f"{row.sample_id}:{barcode}" for barcode in barcodes]
    sample = ad.AnnData(
        X=matrix,
        obs=pd.DataFrame(index=obs_names),
        var=pd.DataFrame(index=gene_names),
    )
    sample.var_names_make_unique()
    sample.obs["sample_id"] = row.sample_id
    sample.obs["donor"] = row.donor_id
    sample.obs["label"] = row.label
    sample.obs["tissue_status"] = row.tissue_status
    sample.obs["primary_validation"] = bool(row.primary_validation)
    sample.obs["dataset"] = "GSE298871"
    return sample


def available(adata: ad.AnnData, genes: list[str]) -> list[str]:
    universe = adata.raw.var_names if adata.raw is not None else adata.var_names
    return [gene for gene in genes if gene in universe]


def score_signatures(adata: ad.AnnData) -> None:
    for name, genes in {
        "IFN_gamma": IFN_GAMMA_GENES,
        "Cytotoxic": CYTOTOXIC_GENES,
        "Trm": TRM_GENES,
    }.items():
        present = available(adata, genes)
        sc.tl.score_genes(
            adata,
            present,
            score_name=name,
            use_raw=True,
            random_state=42,
        )


def annotate_cell_types(adata: ad.AnnData) -> None:
    for cell_type, genes in MARKERS.items():
        present = available(adata, genes)
        sc.tl.score_genes(
            adata,
            present,
            score_name=f"score_{cell_type}",
            use_raw=True,
            random_state=42,
        )
    score_cols = [f"score_{cell_type}" for cell_type in MARKERS]
    cluster_scores = adata.obs.groupby("leiden", observed=True)[score_cols].mean()
    cluster_scores.columns = list(MARKERS)
    mapping = cluster_scores.idxmax(axis=1).to_dict()
    adata.obs["cell_type"] = adata.obs["leiden"].map(mapping).astype(str)

    # The main atlas contains distinct CD4 and CD8 populations, whereas the
    # independent cohort initially forms a broad T-cell cluster. Recluster only
    # T/NK-assigned cells so that CD8 endpoints are not erased by a majority-CD4
    # label at the parent-cluster level.
    lymphoid_types = {"CD4_T", "CD8_T", "Treg", "NK"}
    lymphoid_mask = adata.obs["cell_type"].isin(lymphoid_types)
    if lymphoid_mask.sum() >= 100:
        lymphoid = adata[lymphoid_mask].copy()
        sc.pp.neighbors(lymphoid, use_rep="X_pca", n_neighbors=10, random_state=42)
        sc.tl.leiden(lymphoid, resolution=0.5, random_state=42, key_added="leiden_lymphoid")
        lymphoid_score_cols = [f"score_{cell_type}" for cell_type in lymphoid_types]
        lymphoid_scores = lymphoid.obs.groupby(
            "leiden_lymphoid", observed=True
        )[lymphoid_score_cols].mean()
        lymphoid_scores.columns = [column.removeprefix("score_") for column in lymphoid_score_cols]
        lymphoid_mapping = lymphoid_scores.idxmax(axis=1).to_dict()
        refined = lymphoid.obs["leiden_lymphoid"].map(lymphoid_mapping).astype(str)
        adata.obs.loc[lymphoid.obs_names, "cell_type"] = refined
        lymphoid_scores.assign(
            assigned_cell_type=lymphoid_scores.idxmax(axis=1)
        ).to_csv(OUT_DIR / "lymphoid_cluster_marker_scores.csv")

    adata.obs["cell_type"] = adata.obs["cell_type"].astype("category")
    cluster_scores.assign(assigned_cell_type=cluster_scores.idxmax(axis=1)).to_csv(
        OUT_DIR / "cluster_marker_scores.csv"
    )


def mean_obs(frame: pd.DataFrame, column: str, cell_types: list[str] | None = None) -> float:
    selected = frame if cell_types is None else frame[frame["cell_type"].isin(cell_types)]
    return float(selected[column].mean()) if len(selected) else np.nan


def donor_features_from_obs(obs: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for sample_id, frame in obs.groupby("sample_id", observed=True):
        proportions = frame["cell_type"].value_counts(normalize=True)
        rows.append(
            {
                "sample_id": sample_id,
                "donor": frame["donor"].iloc[0],
                "label": frame["label"].iloc[0],
                "tissue_status": frame["tissue_status"].iloc[0],
                "primary_validation": bool(frame["primary_validation"].iloc[0]),
                "n_cells": len(frame),
                "ifn_all": mean_obs(frame, "IFN_gamma"),
                "ifn_macrophage": mean_obs(frame, "IFN_gamma", ["Macrophage"]),
                "ifn_keratinocyte": mean_obs(
                    frame, "IFN_gamma", ["Keratinocyte_basal", "Keratinocyte_supra"]
                ),
                "cytotoxic_cd8": mean_obs(frame, "Cytotoxic", ["CD8_T"]),
                "trm_cd8": mean_obs(frame, "Trm", ["CD8_T"]),
                "prop_macrophage": float(proportions.get("Macrophage", 0.0)),
                "prop_fibroblast": float(proportions.get("Fibroblast", 0.0)),
                "prop_endothelial": float(proportions.get("Endothelial", 0.0)),
                "prop_cd8": float(proportions.get("CD8_T", 0.0)),
                "prop_melanocyte": float(proportions.get("Melanocyte", 0.0)),
            }
        )
    return pd.DataFrame(rows)


def old_discovery_features() -> pd.DataFrame:
    old = sc.read_h5ad(ROOT / "output" / "adata_annotated.h5ad", backed="r")
    obs = old.obs
    obs = obs[obs["dataset"] == "PRJCA006797"].copy()
    obs["sample_id"] = obs["donor"].astype(str)
    obs["tissue_status"] = np.where(obs["label"] == "patient", "lesional", "healthy")
    obs["primary_validation"] = True
    obs["Trm"] = np.nan
    features = donor_features_from_obs(obs)
    old.file.close()
    return features


def cohort_standardize(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    values = frame[columns].astype(float)
    values = values.fillna(values.median(axis=0))
    means = values.mean(axis=0)
    stds = values.std(axis=0, ddof=0).replace(0, 1.0)
    return ((values - means) / stds).to_numpy()


def cliffs_delta(patient: np.ndarray, healthy: np.ndarray) -> float:
    comparisons = patient[:, None] - healthy[None, :]
    return float((np.sum(comparisons > 0) - np.sum(comparisons < 0)) / comparisons.size)


def bootstrap_cliffs_delta(
    patient: np.ndarray,
    healthy: np.ndarray,
    n_bootstrap: int = 5000,
    seed: int = 42,
) -> tuple[float, float]:
    rng = np.random.default_rng(seed)
    estimates = np.empty(n_bootstrap)
    for index in range(n_bootstrap):
        resampled_patient = rng.choice(patient, size=len(patient), replace=True)
        resampled_healthy = rng.choice(healthy, size=len(healthy), replace=True)
        estimates[index] = cliffs_delta(resampled_patient, resampled_healthy)
    return tuple(np.quantile(estimates, [0.025, 0.975]))


def performance_intervals(
    labels: np.ndarray,
    probabilities: np.ndarray,
    predicted_labels: np.ndarray,
    n_bootstrap: int = 5000,
    seed: int = 42,
) -> dict[str, float]:
    rng = np.random.default_rng(seed)
    negative = np.flatnonzero(labels == 0)
    positive = np.flatnonzero(labels == 1)
    bootstrap_auc = np.empty(n_bootstrap)
    for index in range(n_bootstrap):
        sampled_indices = np.concatenate(
            [
                rng.choice(negative, size=len(negative), replace=True),
                rng.choice(positive, size=len(positive), replace=True),
            ]
        )
        bootstrap_auc[index] = roc_auc_score(
            labels[sampled_indices], probabilities[sampled_indices]
        )
    correct = int(np.sum(labels == predicted_labels))
    accuracy_low, accuracy_high = proportion_confint(
        correct, len(labels), alpha=0.05, method="wilson"
    )
    auc_low, auc_high = np.quantile(bootstrap_auc, [0.025, 0.975])
    return {
        "accuracy": float(accuracy_score(labels, predicted_labels)),
        "accuracy_ci95_low": float(accuracy_low),
        "accuracy_ci95_high": float(accuracy_high),
        "auc": float(roc_auc_score(labels, probabilities)),
        "auc_bootstrap_ci95_low": float(auc_low),
        "auc_bootstrap_ci95_high": float(auc_high),
        "bootstrap_replicates": n_bootstrap,
    }


def endpoint_statistics(primary: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for endpoint, direction in ENDPOINT_DIRECTIONS.items():
        healthy = primary.loc[primary.label == "healthy", endpoint].dropna().to_numpy(float)
        patient = primary.loc[primary.label == "patient", endpoint].dropna().to_numpy(float)
        if len(healthy) < 2 or len(patient) < 2:
            continue
        _, p_value = mannwhitneyu(healthy, patient, alternative="two-sided", method="exact")
        signed_delta = cliffs_delta(patient, healthy)
        delta_low, delta_high = bootstrap_cliffs_delta(patient, healthy)
        values = primary.loc[primary[endpoint].notna(), endpoint].to_numpy(float)
        labels = (primary.loc[primary[endpoint].notna(), "label"] == "patient").astype(int)
        oriented = values if direction == "up" else -values
        rows.append(
            {
                "endpoint": endpoint,
                "expected_direction": direction,
                "healthy_mean": healthy.mean(),
                "patient_mean": patient.mean(),
                "cliffs_delta_patient_minus_healthy": signed_delta,
                "cliffs_delta_ci95_low": delta_low,
                "cliffs_delta_ci95_high": delta_high,
                "auc_expected_direction": roc_auc_score(labels, oriented),
                "p_value": p_value,
                "n_healthy": len(healthy),
                "n_patient": len(patient),
            }
        )
    result = pd.DataFrame(rows)
    result["p_adj_bh"] = multipletests(result["p_value"], method="fdr_bh")[1]
    return result.sort_values(["p_adj_bh", "p_value"])


def raw_gene_mean(
    adata: ad.AnnData, sample_id: str, gene: str, cell_types: list[str]
) -> float:
    mask = (adata.obs["sample_id"] == sample_id) & adata.obs["cell_type"].isin(cell_types)
    if not mask.any() or gene not in adata.raw.var_names:
        return np.nan
    matrix = adata.raw[mask.to_numpy(), [gene]].X
    return float(np.asarray(matrix.mean(axis=0)).ravel()[0])


def gene_validation(adata: ad.AnnData, primary: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for endpoint, (gene, cell_types) in GENE_TARGETS.items():
        values = {
            sample_id: raw_gene_mean(adata, sample_id, gene, cell_types)
            for sample_id in primary.sample_id
        }
        healthy = np.array(
            [values[s] for s in primary.loc[primary.label == "healthy", "sample_id"]], dtype=float
        )
        patient = np.array(
            [values[s] for s in primary.loc[primary.label == "patient", "sample_id"]], dtype=float
        )
        healthy = healthy[~np.isnan(healthy)]
        patient = patient[~np.isnan(patient)]
        if len(healthy) < 2 or len(patient) < 2:
            continue
        _, p_value = mannwhitneyu(healthy, patient, alternative="two-sided", method="exact")
        rows.append(
            {
                "endpoint": endpoint,
                "gene": gene,
                "cell_type": "+".join(cell_types),
                "healthy_mean_log_normalized": healthy.mean(),
                "patient_mean_log_normalized": patient.mean(),
                "cliffs_delta_patient_minus_healthy": cliffs_delta(patient, healthy),
                "p_value": p_value,
                "n_healthy": len(healthy),
                "n_patient": len(patient),
            }
        )
    result = pd.DataFrame(rows)
    if len(result):
        result["p_adj_bh"] = multipletests(result["p_value"], method="fdr_bh")[1]
    return result.sort_values(["p_adj_bh", "p_value"])


def paired_sensitivity(features: pd.DataFrame) -> pd.DataFrame:
    paired = features[features.donor.isin(["486", "DER114", "DER115", "DER119", "DER120"])]
    rows = []
    for endpoint in ENDPOINT_DIRECTIONS:
        wide = paired.pivot(index="donor", columns="tissue_status", values=endpoint).dropna()
        if not {"lesional", "nonlesional"}.issubset(wide.columns) or len(wide) < 3:
            continue
        try:
            _, p_value = wilcoxon(wide["lesional"], wide["nonlesional"], alternative="two-sided")
        except ValueError:
            p_value = 1.0
        rows.append(
            {
                "endpoint": endpoint,
                "n_pairs": len(wide),
                "lesional_mean": wide["lesional"].mean(),
                "nonlesional_mean": wide["nonlesional"].mean(),
                "mean_paired_difference": (wide["lesional"] - wide["nonlesional"]).mean(),
                "wilcoxon_p_value": p_value,
            }
        )
    result = pd.DataFrame(rows)
    if len(result):
        result["p_adj_bh"] = multipletests(result["wilcoxon_p_value"], method="fdr_bh")[1]
    return result.sort_values(["p_adj_bh", "wilcoxon_p_value"])


def make_figure(
    adata: ad.AnnData,
    primary: pd.DataFrame,
    predictions: pd.DataFrame,
    endpoint_stats: pd.DataFrame,
    performance: dict[str, float],
) -> None:
    sns.set_theme(style="ticks", context="paper")
    matplotlib.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
            "font.size": 7.5,
            "font.weight": "bold",
            "axes.titlesize": 8.5,
            "axes.titleweight": "bold",
            "axes.labelsize": 7.8,
            "axes.labelweight": "bold",
            "xtick.labelsize": 7,
            "ytick.labelsize": 7,
            "legend.fontsize": 7,
            "axes.spines.right": False,
            "axes.spines.top": False,
            "pdf.fonttype": 42,
            "svg.fonttype": "none",
        }
    )
    healthy_color = "#2A9D8F"
    patient_color = "#C84C5A"
    neutral_color = "#777777"
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 6.1))

    sc.pl.umap(
        adata,
        color="tissue_status",
        palette={"healthy": healthy_color, "lesional": patient_color, "nonlesional": "#D9A441"},
        ax=axes[0, 0],
        show=False,
        title="Independent skin cohort (22,071 cells)",
        size=5,
        frameon=False,
        legend_loc=None,
    )
    axes[0, 0].legend(
        handles=[
            Line2D(
                [0], [0], marker="o", color="none", markerfacecolor=healthy_color,
                markeredgecolor="white", label="Healthy"
            ),
            Line2D(
                [0], [0], marker="o", color="none", markerfacecolor=patient_color,
                markeredgecolor="white", label="Lesional"
            ),
            Line2D(
                [0], [0], marker="o", color="none", markerfacecolor="#D9A441",
                markeredgecolor="white", label="Non-lesional"
            ),
        ],
        loc="lower center",
        bbox_to_anchor=(0.5, 0.01),
        ncol=3,
        columnspacing=0.7,
        handletextpad=0.3,
        borderpad=0.3,
    )
    axes[0, 0].text(
        -0.13, 1.05, "a", transform=axes[0, 0].transAxes, fontsize=9, fontweight="bold"
    )

    ordered = predictions.sort_values("predicted_probability").reset_index(drop=True)
    colors = np.where(ordered.true_label.eq(1), patient_color, healthy_color)
    positions = np.arange(len(ordered))
    axes[0, 1].hlines(
        positions,
        0,
        ordered.predicted_probability,
        color=colors,
        alpha=0.35,
        linewidth=1.2,
    )
    axes[0, 1].scatter(
        ordered.predicted_probability,
        positions,
        c=colors,
        s=28,
        edgecolor="white",
        linewidth=0.5,
        zorder=3,
    )
    axes[0, 1].axvline(0.5, color=neutral_color, linestyle="--", linewidth=0.8)
    axes[0, 1].set_yticks(positions, ordered["donor"].astype(str))
    axes[0, 1].set_xlim(0, 1)
    axes[0, 1].set_xlabel("Predicted probability of vitiligo")
    axes[0, 1].set_ylabel("Independent donor")
    axes[0, 1].set_title(
        "PRJCA006797-trained model tested once on GSE298871\n"
        f"AUC {performance['auc']:.3f} "
        f"(95% CI {performance['auc_bootstrap_ci95_low']:.3f}–"
        f"{performance['auc_bootstrap_ci95_high']:.3f}); "
        f"accuracy {performance['accuracy']:.2f}"
    )
    axes[0, 1].text(
        -0.15, 1.05, "b", transform=axes[0, 1].transAxes, fontsize=9, fontweight="bold"
    )
    axes[0, 1].legend(
        handles=[
            Line2D(
                [0], [0], marker="o", color="none", markerfacecolor=healthy_color,
                markeredgecolor="white", label="Healthy"
            ),
            Line2D(
                [0], [0], marker="o", color="none", markerfacecolor=patient_color,
                markeredgecolor="white", label="Lesional vitiligo"
            ),
        ],
        loc="lower right",
    )

    plot_endpoints = [
        "prop_melanocyte",
        "prop_macrophage",
        "ifn_macrophage",
        "cytotoxic_cd8",
    ]
    long = primary.melt(
        id_vars=["sample_id", "label"],
        value_vars=plot_endpoints,
        var_name="endpoint",
        value_name="value",
    )
    long["z_value"] = long.groupby("endpoint")["value"].transform(
        lambda values: (values - values.mean()) / (values.std(ddof=0) or 1.0)
    )
    sns.boxplot(
        data=long,
        x="endpoint",
        y="z_value",
        hue="label",
        palette={"healthy": healthy_color, "patient": patient_color},
        showfliers=False,
        linewidth=0.8,
        ax=axes[1, 0],
    )
    sns.stripplot(
        data=long,
        x="endpoint",
        y="z_value",
        hue="label",
        dodge=True,
        palette={"healthy": healthy_color, "patient": patient_color},
        size=3.5,
        linewidth=0.4,
        edgecolor="white",
        ax=axes[1, 0],
    )
    handles, labels = axes[1, 0].get_legend_handles_labels()
    axes[1, 0].legend(handles[:2], ["Healthy", "Vitiligo"], frameon=False)
    axes[1, 0].set_xticks(
        range(4),
        [
            "Melanocyte\nfraction",
            "Macrophage\nfraction",
            "Macrophage\nIFN-γ",
            "CD8\ncytotoxicity",
        ],
    )
    axes[1, 0].set_xlabel("")
    axes[1, 0].set_ylabel("Within-cohort z-score")
    axes[1, 0].set_title("Prespecified biological endpoints")
    axes[1, 0].text(
        -0.13, 1.05, "c", transform=axes[1, 0].transAxes, fontsize=9, fontweight="bold"
    )

    effect_order = [
        "prop_melanocyte",
        "prop_macrophage",
        "ifn_keratinocyte",
        "prop_cd8",
        "ifn_macrophage",
        "ifn_all",
        "trm_cd8",
        "cytotoxic_cd8",
        "prop_fibroblast",
        "prop_endothelial",
    ]
    effect_labels = {
        "prop_melanocyte": "Melanocyte fraction ↓",
        "prop_macrophage": "Macrophage fraction ↑",
        "ifn_keratinocyte": "Keratinocyte IFN-γ ↑",
        "prop_cd8": "CD8 fraction ↑",
        "ifn_macrophage": "Macrophage IFN-γ ↑",
        "ifn_all": "Pan-cell IFN-γ ↑",
        "trm_cd8": "CD8 Trm ↑",
        "cytotoxic_cd8": "CD8 cytotoxicity ↑",
        "prop_fibroblast": "Fibroblast fraction ↓",
        "prop_endothelial": "Endothelial fraction ↓",
    }
    effects = endpoint_stats.set_index("endpoint").loc[effect_order].copy()
    effects["oriented_delta"] = np.where(
        effects.expected_direction.eq("up"),
        effects.cliffs_delta_patient_minus_healthy,
        -effects.cliffs_delta_patient_minus_healthy,
    )
    effects["oriented_low"] = np.where(
        effects.expected_direction.eq("up"),
        effects.cliffs_delta_ci95_low,
        -effects.cliffs_delta_ci95_high,
    )
    effects["oriented_high"] = np.where(
        effects.expected_direction.eq("up"),
        effects.cliffs_delta_ci95_high,
        -effects.cliffs_delta_ci95_low,
    )
    y_positions = np.arange(len(effects))[::-1]
    effect_colors = np.where(effects.oriented_delta >= 0, "#3C78A8", "#B55D60")
    axes[1, 1].axvline(0, color=neutral_color, linewidth=0.8, linestyle="--")
    axes[1, 1].errorbar(
        effects.oriented_delta,
        y_positions,
        xerr=np.vstack(
            [
                effects.oriented_delta - effects.oriented_low,
                effects.oriented_high - effects.oriented_delta,
            ]
        ),
        fmt="none",
        ecolor="#9A9A9A",
        elinewidth=1,
        capsize=2,
    )
    axes[1, 1].scatter(effects.oriented_delta, y_positions, c=effect_colors, s=24, zorder=3)
    axes[1, 1].set_yticks(y_positions, [effect_labels[item] for item in effects.index])
    axes[1, 1].set_xlim(-1.05, 1.05)
    axes[1, 1].set_xlabel("Direction-oriented Cliff's δ (95% bootstrap CI)")
    axes[1, 1].set_title("Effect-size replication in 6 vs 6 donors")
    axes[1, 1].text(
        -0.15, 1.05, "d", transform=axes[1, 1].transAxes, fontsize=9, fontweight="bold"
    )
    sns.despine(fig=fig)
    for item in fig.findobj(match=matplotlib.text.Text):
        if item.get_text().strip():
            item.set_fontweight("bold")
    fig.subplots_adjust(
        left=0.10, right=0.98, bottom=0.08, top=0.94, wspace=0.42, hspace=0.38
    )
    fig.savefig(OUT_DIR / "fig9_external_validation.png", dpi=300, bbox_inches="tight")
    fig.savefig(OUT_DIR / "fig9_external_validation.pdf", bbox_inches="tight")
    fig.savefig(OUT_DIR / "fig9_external_validation.svg", bbox_inches="tight")
    fig.savefig(
        OUT_DIR / "fig9_external_validation.tiff",
        dpi=600,
        bbox_inches="tight",
        pil_kwargs={"compression": "tiff_lzw"},
    )
    plt.close(fig)


def main() -> None:
    print("Loading 17 GSE298871 samples...")
    samples = [read_sample(row) for _, row in MANIFEST.iterrows()]
    adata = ad.concat(samples, join="inner", merge="same", index_unique=None)
    del samples
    print(f"Raw matrix: {adata.n_obs:,} cells x {adata.n_vars:,} genes")

    adata.var["mt"] = adata.var_names.str.startswith("MT-")
    sc.pp.calculate_qc_metrics(adata, qc_vars=["mt"], inplace=True)
    before_by_sample = adata.obs.groupby("sample_id", observed=True).size().rename("cells_before_qc")
    keep = (
        (adata.obs["n_genes_by_counts"] >= 200)
        & (adata.obs["n_genes_by_counts"] <= 6000)
        & (adata.obs["total_counts"] >= 500)
        & (adata.obs["total_counts"] <= 50000)
        & (adata.obs["pct_counts_mt"] < 20)
    )
    adata = adata[keep].copy()
    after_by_sample = adata.obs.groupby("sample_id", observed=True).size().rename("cells_after_qc")
    qc = MANIFEST.merge(
        pd.concat([before_by_sample, after_by_sample], axis=1).reset_index(),
        on="sample_id",
        how="left",
    )
    qc["retention_fraction"] = qc.cells_after_qc / qc.cells_before_qc
    qc.to_csv(OUT_DIR / "gse298871_qc_manifest.csv", index=False)
    print(f"After QC: {adata.n_obs:,} cells")

    sc.pp.normalize_total(adata, target_sum=1e4)
    sc.pp.log1p(adata)
    adata.raw = adata.copy()
    sc.pp.highly_variable_genes(adata, n_top_genes=3000, batch_key="sample_id")
    adata = adata[:, adata.var["highly_variable"]].copy()
    sc.pp.scale(adata, max_value=10)
    sc.tl.pca(adata, n_comps=50, random_state=42)
    sc.pp.neighbors(adata, use_rep="X_pca", n_neighbors=15, random_state=42)
    sc.tl.umap(adata, random_state=42)
    sc.tl.leiden(adata, resolution=0.6, random_state=42)
    annotate_cell_types(adata)
    score_signatures(adata)

    features = donor_features_from_obs(adata.obs)
    features.to_csv(OUT_DIR / "gse298871_donor_features.csv", index=False)
    primary = features[features.primary_validation].copy()
    primary.to_csv(OUT_DIR / "gse298871_primary_validation_features.csv", index=False)

    endpoint_stats = endpoint_statistics(primary)
    endpoint_stats.to_csv(OUT_DIR / "gse298871_endpoint_statistics.csv", index=False)
    gene_stats = gene_validation(adata, primary)
    gene_stats.to_csv(OUT_DIR / "gse298871_gene_validation.csv", index=False)
    paired_stats = paired_sensitivity(features)
    paired_stats.to_csv(OUT_DIR / "gse298871_paired_sensitivity.csv", index=False)

    discovery = old_discovery_features()
    x_discovery = cohort_standardize(discovery, CLASSIFIER_FEATURES)
    x_external = cohort_standardize(primary, CLASSIFIER_FEATURES)
    y_discovery = (discovery.label == "patient").astype(int).to_numpy()
    y_external = (primary.label == "patient").astype(int).to_numpy()
    classifier = make_pipeline(
        SimpleImputer(strategy="median"),
        StandardScaler(),
        LogisticRegression(C=0.2, penalty="l2", solver="liblinear", random_state=42),
    )
    classifier.fit(x_discovery, y_discovery)
    probabilities = classifier.predict_proba(x_external)[:, 1]
    predictions = pd.DataFrame(
        {
            "sample_id": primary.sample_id.to_numpy(),
            "donor": primary.donor.to_numpy(),
            "true_label": y_external,
            "predicted_probability": probabilities,
            "predicted_label": (probabilities >= 0.5).astype(int),
        }
    )
    predictions.to_csv(OUT_DIR / "gse298871_external_predictions.csv", index=False)
    performance = performance_intervals(
        y_external, probabilities, predictions.predicted_label.to_numpy()
    )

    summary = {
        "accession": "GSE298871",
        "raw_cells": int(qc.cells_before_qc.sum()),
        "cells_after_qc": int(qc.cells_after_qc.sum()),
        "unique_donors_total": int(MANIFEST.donor_id.nunique()),
        "primary_validation_donors": int(primary.donor.nunique()),
        "primary_healthy_donors": int((primary.label == "healthy").sum()),
        "primary_lesional_vitiligo_donors": int((primary.label == "patient").sum()),
        "paired_nonlesional_donors": 5,
        "external_accuracy": performance["accuracy"],
        "external_accuracy_wilson_ci95": [
            performance["accuracy_ci95_low"],
            performance["accuracy_ci95_high"],
        ],
        "external_auc": performance["auc"],
        "external_auc_stratified_bootstrap_ci95": [
            performance["auc_bootstrap_ci95_low"],
            performance["auc_bootstrap_ci95_high"],
        ],
        "performance_ci_bootstrap_replicates": performance["bootstrap_replicates"],
        "classifier_training_cohort": "PRJCA006797 only (5 healthy, 10 vitiligo)",
        "classifier_test_cohort": "GSE298871 only (6 healthy, 6 lesional vitiligo)",
        "test_labels_used_for_training": False,
        "external_standardization": (
            "Cohort-wise unlabeled centering/scaling using all 12 external feature vectors; "
            "no external disease labels used"
        ),
    }
    (OUT_DIR / "validation_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n"
    )

    make_figure(adata, primary, predictions, endpoint_stats, performance)
    adata.obs.to_csv(OUT_DIR / "gse298871_cell_metadata.csv")
    adata.write_h5ad(OUT_DIR / "gse298871_annotated.h5ad", compression="gzip")

    print(json.dumps(summary, indent=2))
    print("\nEndpoint statistics:")
    print(endpoint_stats.to_string(index=False))
    print("\nGene validation:")
    print(gene_stats.to_string(index=False))


if __name__ == "__main__":
    main()
