"""Analyses added in response to peer review.

This script produces three auditable outputs without changing the discovery
atlas labels:

1. Benjamini--Hochberg correction across all 11 donor-level cell-composition
   comparisons.
2. Five-fold donor-level gated-attention MIL restricted to PRJCA006797, the
   only discovery dataset containing both healthy and vitiligo donors.
3. A post-annotation dot plot validating T-cell labels with pan-T, lineage,
   state, and myeloid-exclusion markers.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

import anndata as ad
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scanpy as sc
import torch
from scipy.stats import mannwhitneyu
from sklearn.metrics import accuracy_score, confusion_matrix, roc_auc_score
from sklearn.model_selection import StratifiedKFold
from statsmodels.stats.multitest import multipletests
from statsmodels.stats.proportion import proportion_confint

from baseline_comparison import fit_mil


ROOT = Path(
    os.environ.get("VITILIGO_PROJECT_ROOT", Path(__file__).resolve().parents[1])
).resolve()
ADATA_PATH = ROOT / "output" / "adata_annotated.h5ad"
REVISION_DIR = ROOT / "output" / "reviewer_revision"
FIGURE_DIR = REVISION_DIR / "figures"
SUPPLEMENT_DIR = REVISION_DIR

REVISION_DIR.mkdir(parents=True, exist_ok=True)
FIGURE_DIR.mkdir(parents=True, exist_ok=True)


def composition_statistics(adata: ad.AnnData) -> pd.DataFrame:
    """Test all annotated cell-type proportions at the biological-donor level."""
    obs = adata.obs[["donor", "label", "cell_type"]].copy()
    counts = obs.groupby(["donor", "cell_type"], observed=False).size().unstack(fill_value=0)
    proportions = counts.div(counts.sum(axis=1), axis=0) * 100
    donor_label = obs.groupby("donor", observed=False)["label"].first()

    rows: list[dict] = []
    for cell_type in proportions.columns:
        healthy = proportions.loc[donor_label == "healthy", cell_type].to_numpy()
        patient = proportions.loc[donor_label == "patient", cell_type].to_numpy()
        statistic, p_value = mannwhitneyu(
            healthy, patient, alternative="two-sided", method="asymptotic"
        )
        # Positive values indicate larger proportions in vitiligo.
        cliffs_delta = 1.0 - 2.0 * statistic / (len(healthy) * len(patient))
        rows.append(
            {
                "cell_type": str(cell_type),
                "healthy_mean_percent": healthy.mean(),
                "patient_mean_percent": patient.mean(),
                "mann_whitney_u": statistic,
                "p_raw": p_value,
                "cliffs_delta_patient_vs_healthy": cliffs_delta,
                "direction": "higher_in_vitiligo"
                if patient.mean() > healthy.mean()
                else "lower_in_vitiligo",
            }
        )

    result = pd.DataFrame(rows)
    result["q_bh"] = multipletests(result["p_raw"], method="fdr_bh")[1]
    result["significant_q_lt_0_05"] = result["q_bh"] < 0.05
    return result.sort_values(["q_bh", "p_raw", "cell_type"]).reset_index(drop=True)


def prjca_only_mil(adata: ad.AnnData) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    """Repeat the prespecified donor-level MIL CV within PRJCA006797 only."""
    obs_all = adata.obs[["donor", "label", "dataset"]].copy()
    mask = (obs_all["dataset"].astype(str) == "PRJCA006797").to_numpy()
    obs = obs_all.iloc[np.flatnonzero(mask)].copy()
    embedding = np.asarray(adata.obsm["X_pca_harmony"])[mask].astype(np.float32)

    donors = obs["donor"].astype(str).drop_duplicates().tolist()
    donor_values = obs["donor"].astype(str).to_numpy()
    labels = {
        donor: int(
            obs.loc[obs["donor"].astype(str) == donor, "label"].iloc[0] == "patient"
        )
        for donor in donors
    }
    donor_x = {donor: embedding[donor_values == donor] for donor in donors}
    y = np.asarray([labels[donor] for donor in donors], dtype=int)
    probabilities = np.full(len(donors), np.nan)
    folds = np.full(len(donors), -1, dtype=int)

    outer = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    for fold, (train_idx, test_idx) in enumerate(outer.split(donors, y), start=1):
        train_donors = [donors[i] for i in train_idx]
        test_donors = [donors[i] for i in test_idx]
        probabilities[test_idx] = fit_mil(
            "attention",
            train_donors,
            test_donors,
            donor_x,
            labels,
            2026 + fold,
        )
        folds[test_idx] = fold

    predictions = (probabilities >= 0.5).astype(int)
    prediction_table = pd.DataFrame(
        {
            "donor": donors,
            "dataset": "PRJCA006797",
            "outer_fold": folds,
            "true_label": y,
            "predicted_probability": probabilities,
            "predicted_label": predictions,
            "correct": predictions == y,
        }
    )

    accuracy = accuracy_score(y, predictions)
    auc = roc_auc_score(y, probabilities)
    acc_low, acc_high = proportion_confint(
        int((predictions == y).sum()), len(y), alpha=0.05, method="wilson"
    )
    matrix = confusion_matrix(y, predictions, labels=[0, 1])
    summary = {
        "analysis": "PRJCA006797-only gated-attention MIL",
        "cross_validation": "5-fold stratified donor-level CV",
        "outer_seed": 42,
        "model_seed_base": 2026,
        "probability_threshold": 0.5,
        "n_donors": len(donors),
        "n_healthy": int((y == 0).sum()),
        "n_vitiligo": int((y == 1).sum()),
        "accuracy": accuracy,
        "accuracy_wilson_ci95_low": float(acc_low),
        "accuracy_wilson_ci95_high": float(acc_high),
        "auc": auc,
        "true_negative": int(matrix[0, 0]),
        "false_positive": int(matrix[0, 1]),
        "false_negative": int(matrix[1, 0]),
        "true_positive": int(matrix[1, 1]),
    }
    summary_table = pd.DataFrame([summary])
    return prediction_table, summary_table, summary


def dataset_error_distribution() -> pd.DataFrame:
    """Summarise original out-of-fold attention-MIL errors by source dataset."""
    path = ROOT / "output" / "baseline_comparison" / "baseline_oof_predictions.csv"
    frame = pd.read_csv(path)
    frame = frame.loc[frame["method"] == "Gated-attention MIL"].copy()
    frame["correct"] = frame["true_label"] == frame["predicted_label"]
    result = (
        frame.groupby("dataset", as_index=False)
        .agg(
            n_donors=("donor", "size"),
            n_correct=("correct", "sum"),
            accuracy=("correct", "mean"),
            n_misclassified=("correct", lambda values: int((~values).sum())),
        )
        .sort_values("dataset")
    )
    return result


def tcell_validation_figure(adata: ad.AnnData) -> None:
    """Create post-annotation validation plot without relabelling cells."""
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
            "font.size": 7,
            "font.weight": "normal",
            "axes.titleweight": "bold",
            "pdf.fonttype": 42,
            "svg.fonttype": "none",
        }
    )

    immune_order = ["CD4_T", "CD8_T", "Plasma_B", "Dendritic", "Macrophage"]
    immune_order = [value for value in immune_order if value in adata.obs["cell_type"].unique()]
    immune = adata[adata.obs["cell_type"].isin(immune_order)].copy()
    immune.obs["cell_type"] = pd.Categorical(
        immune.obs["cell_type"].astype(str), categories=immune_order, ordered=True
    )
    genes = {
        "Pan-T identity": ["CD3D", "CD3E", "TRAC"],
        "CD4-associated": ["CD4", "IL7R", "MAL"],
        "CD8-associated": ["CD8A", "CD8B"],
        "Effector state": ["GZMK", "PRF1", "NKG7"],
        "Myeloid exclusion": ["LYZ", "LST1", "FCER1G"],
    }
    genes = {
        group: [gene for gene in values if gene in adata.raw.var_names]
        for group, values in genes.items()
    }

    plot = sc.pl.dotplot(
        immune,
        genes,
        groupby="cell_type",
        categories_order=immune_order,
        use_raw=True,
        standard_scale="var",
        color_map="Blues",
        dot_min=0,
        dot_max=1,
        show=False,
        return_fig=True,
        title="Orthogonal validation of T-cell annotations",
    )
    plot.style(cmap="Blues", dot_edge_color="black", dot_edge_lw=0.25)
    plot.make_figure()
    fig = plot.get_axes()["mainplot_ax"].figure
    fig.set_size_inches(7.2, 3.8)
    for axis in fig.axes:
        axis.tick_params(labelsize=7)
        for label in axis.get_xticklabels() + axis.get_yticklabels():
            label.set_fontweight("normal")
    base = FIGURE_DIR / "supp_fig_s1_tcell_annotation"
    fig.savefig(base.with_suffix(".svg"), bbox_inches="tight")
    fig.savefig(base.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(base.with_suffix(".tiff"), dpi=600, bbox_inches="tight")
    fig.savefig(base.with_suffix(".png"), dpi=300, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    torch.set_num_threads(4)
    adata = ad.read_h5ad(ADATA_PATH)

    composition = composition_statistics(adata)
    composition.to_csv(REVISION_DIR / "cell_type_composition_bh.csv", index=False)

    predictions, prjca_summary, summary_json = prjca_only_mil(adata)
    predictions.to_csv(REVISION_DIR / "prjca_only_mil_predictions.csv", index=False)
    prjca_summary.to_csv(REVISION_DIR / "prjca_only_mil_summary.csv", index=False)
    (REVISION_DIR / "prjca_only_mil_summary.json").write_text(
        json.dumps(summary_json, indent=2), encoding="utf-8"
    )

    by_dataset = dataset_error_distribution()
    by_dataset.to_csv(REVISION_DIR / "mil_errors_by_dataset.csv", index=False)

    workbook = SUPPLEMENT_DIR / "Table_S13_dataset_confounding_checks.xlsx"
    with pd.ExcelWriter(workbook) as writer:
        prjca_summary.to_excel(writer, sheet_name="PRJCA_only_summary", index=False)
        predictions.to_excel(writer, sheet_name="PRJCA_only_predictions", index=False)
        by_dataset.to_excel(writer, sheet_name="Errors_by_dataset", index=False)
    with pd.ExcelWriter(REVISION_DIR / "cell_type_composition_bh.xlsx") as writer:
        composition.to_excel(writer, sheet_name="Composition_BH", index=False)

    tcell_validation_figure(adata)

    print(composition.to_string(index=False))
    print("\nPRJCA006797-only MIL")
    print(prjca_summary.to_string(index=False))
    print("\nOriginal OOF errors by dataset")
    print(by_dataset.to_string(index=False))


if __name__ == "__main__":
    main()
