"""Small checks that do not require public scRNA-seq matrices."""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import baseline_comparison as baseline
from external_validation_global_test import (
    balanced_label_permutations,
    exact_upper_tail_p,
)


def test_mil_forward_and_training() -> None:
    donor_x = {
        "H1": np.zeros((4, 50), dtype=np.float32),
        "H2": np.full((4, 50), 0.1, dtype=np.float32),
        "P1": np.full((4, 50), 0.9, dtype=np.float32),
        "P2": np.ones((4, 50), dtype=np.float32),
    }
    labels = {"H1": 0, "H2": 0, "P1": 1, "P2": 1}
    original_epochs = baseline.N_EPOCHS
    baseline.N_EPOCHS = 2
    try:
        for pooling in ("attention", "mean"):
            probabilities = baseline.fit_mil(
                pooling,
                ["H1", "P1", "H2"],
                ["P2"],
                donor_x,
                labels,
                seed=7,
            )
            assert probabilities.shape == (1,)
            assert np.isfinite(probabilities).all()
            assert ((probabilities >= 0) & (probabilities <= 1)).all()
    finally:
        baseline.N_EPOCHS = original_epochs


def test_exact_permutations() -> None:
    permutations = list(balanced_label_permutations(4, 2))
    assert len(permutations) == 6
    assert all(int(labels.sum()) == 2 for labels in permutations)
    p_value = exact_upper_tail_p(0.75, np.array([0.5, 0.75, 1.0, np.nan]))
    assert np.isclose(p_value, 2 / 3)


if __name__ == "__main__":
    test_mil_forward_and_training()
    test_exact_permutations()
    print("Smoke checks passed.")

